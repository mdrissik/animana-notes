// Animana Notes AI — content script v5
// DOM structure confirmed by live inspection:
// - History table rows: tr.mana-date-spacer for date headers
// - Entry rows: 8 cells — [0]=checkbox, [1]=type, [2]=content, [3]=vet initials
// - Patient sidebar: "Chloe (46599)\nCanine   Papillon crossbreed\nfemale spayed\n12 years and 3 months\n9.8 Kg\nmicrochip number 528150002506770"

function findLabel(ta) {
  if (ta.id) { const l = document.querySelector(`label[for="${ta.id}"]`); if (l) return l.textContent.trim(); }
  let el = ta.previousElementSibling;
  while (el) { const t = el.textContent.trim(); if (t && t.length < 80) return t; el = el.previousElementSibling; }
  const p = ta.parentElement;
  if (p) { const l = p.querySelector('label'); if (l && !l.contains(ta)) return l.textContent.trim(); }
  return ta.placeholder || ta.name || '';
}

function scrapeCurrentFrame() {
  const data = {
    patient: {}, client: {}, recentHistory: [],
    isConsultForm: false, frameUrl: window.location.href, frameHasContent: false,
  };

  const bodyText = document.body ? (document.body.innerText || '') : '';
  if (bodyText.trim().length < 30) return data;
  data.frameHasContent = true;

  // ── Consult form detection ──────────────────────────────────────────────
  const textareas = [...document.querySelectorAll('textarea')];
  const phText = textareas.map(t => t.placeholder || '').join(' ').toLowerCase();
  data.isConsultForm = (
    /GENERAL-CONSULT/i.test(bodyText.substring(0, 800)) ||
    /enter history|enter finding|enter diagnos|enter plan/i.test(phText)
  ) && textareas.length >= 2;

  // ── Patient name: "Chloe (46599)" ──────────────────────────────────────
  const pid = bodyText.match(/\b([A-Z][a-z]{1,20})\s*\(\d{4,6}\)/);
  if (pid) data.patient.name = pid[1];
  if (!data.patient.name) {
    const pm = bodyText.match(/Patient:\s*([A-Z][a-z]{1,20})/);
    if (pm) data.patient.name = pm[1];
  }

  // ── Species/breed: "Canine   Papillon crossbreed" (spaces not newline) ─
  const sb = bodyText.match(/(Canine|Feline|Avian|Rabbit|Rodent|Reptile|Equine|Bovine|Porcine)[^\S\n]{1,8}([A-Z][a-z]+(?:[^\S\n][a-z]+){0,3})/);
  if (sb) { data.patient.species = sb[1]; data.patient.breed = sb[2].trim(); }
  if (!data.patient.species) {
    const sm = bodyText.match(/Signalment:\s*(Canine|Feline|Avian|Rabbit|Rodent|Reptile|Equine)/i);
    if (sm) data.patient.species = sm[1];
  }
  if (!data.patient.breed) {
    const bm = bodyText.match(/Signalment:[^,]+,\s*([A-Z][a-z]+(?:\s+[a-z]+){0,3}),/);
    if (bm) data.patient.breed = bm[1];
  }

  // ── Sex: "female spayed" ───────────────────────────────────────────────
  const sx = bodyText.match(/\b(female spayed|male castrated|male neutered|neutered male|spayed female|female intact|male intact|female|male)\b/i);
  if (sx) data.patient.sex = sx[1];

  // ── Age: "12 years and 3 months" ──────────────────────────────────────
  const ag = bodyText.match(/(\d+\s+years?\s+and\s+\d+\s+(?:months?|wks?|weeks?)|\d+\s+years?|\d+\s+months?\s+and\s+\d+\s+wks?)/i);
  if (ag) data.patient.age = ag[0].trim();

  // ── Weight: "9.8 Kg" ──────────────────────────────────────────────────
  const wt = bodyText.match(/(\d+\.?\d*)\s*[Kk]g/);
  if (wt) data.patient.weight = wt[1] + ' kg';

  // ── Microchip: "microchip number 528150002506770" ──────────────────────
  const mc = bodyText.match(/microchip\s+(?:number\s+)?(\d{10,20})/i) || bodyText.match(/\b(\d{15})\b/);
  if (mc) data.patient.microchip = mc[1];

  // ── Passport: "passport NLEP0000104737" ───────────────────────────────
  const pp = bodyText.match(/passport\s+([A-Z]{2,4}\d{6,12})/i);
  if (pp) data.patient.passport = pp[1];

  // ── Client: "Dr. MD Rissik (Michael)" ────────────────────────────────
  const cn = bodyText.match(/Dr\.?\s+[A-Z]{1,3}\s+([A-Z][a-z]+)\s+\(([^)]+)\)/);
  if (cn) { data.client.surname = cn[1]; data.client.firstName = cn[2]; data.client.name = cn[2] + ' ' + cn[1]; }

  // ── CPH: "CPH: 8638728" ───────────────────────────────────────────────
  const cph = bodyText.match(/CPH:\s*(\d{5,12})/i);
  if (cph) data.client.cph = cph[1];

  // ── Signalment line ───────────────────────────────────────────────────
  const sig = bodyText.match(/Signalment:\s*([^\n]{10,150})/);
  if (sig) data.patient.signalment = sig[1].trim();

  // ── Scrape history from mana-date-spacer table rows ───────────────────
  // Confirmed DOM structure:
  //   tr.mana-date-spacer  → date header (1 cell)
  //   tr (8 cells)         → cells[1]=type, cells[2]=content, cells[3]=vet initials
  //
  // Clinical types to capture:
  const CLINICAL = /^(note|dental|general|surgery|consult|anamnese|vaccinati|controle|check|opname|admittance|prescription|diagnos|behandel)/i;
  const SKIP     = /^(uninvoiced|product|estimate|weight|petscan|telefoon|phone|brief|letter|email|reminder|task|bijlage|attachment|overige|gewicht|appointment|afspraak)/i;

  const dateRow = document.querySelector('tr.mana-date-spacer');
  const historyTable = dateRow?.closest('table');

  if (historyTable) {
    const allRows = [...historyTable.querySelectorAll('tr')];
    let currentDate = null;

    allRows.forEach(row => {
      const cls = row.getAttribute('class') || '';

      // Date header row
      if (cls.includes('mana-date-spacer')) {
        const m = (row.innerText || '').match(/(\d{2}-\d{2}-\d{4})/);
        if (m) currentDate = m[1];
        return;
      }

      if (!currentDate) return;

      // Entry row: must have 8 cells (confirmed structure)
      const cells = row.cells;
      if (!cells || cells.length < 3) return;

      const type    = (cells[1]?.innerText || '').trim().toLowerCase();
      const content = (cells[2]?.innerText || '').trim();
      const vet     = (cells[3]?.innerText || '').trim();

      if (!type || SKIP.test(type)) return;
      if (content.length < 20) return;
      if (/^time:\s*\d{2}:\d{2}$/.test(content)) return;

      data.recentHistory.push({
        date: currentDate,
        type,
        content: content.substring(0, 800),
        vet,
      });
    });
  }

  // Fallback: if no table found, parse SOAP blocks from raw text
  if (!data.recentHistory.length) {
    const blocks = [
      ['Subjective',  /Subjective:\s*([\s\S]{10,600}?)(?=\nObjective:|\nAssessment:|$)/i],
      ['Objective',   /Objective:\s*([\s\S]{10,600}?)(?=\nAssessment:|\nPlan:|$)/i],
      ['Assessment',  /Assessment:\s*([\s\S]{10,400}?)(?=\nPlan:|$)/i],
      ['Plan',        /Plan:\s*([\s\S]{10,600}?)(?=\n\d{2}-\d{2}-\d{4}|\n\t|$)/i],
    ];
    blocks.forEach(([label, re]) => {
      const m = bodyText.match(re);
      if (m) data.recentHistory.push({ date: 'recent', type: label.toLowerCase(), content: m[1].trim().substring(0, 500) });
    });
  }

  return data;
}

function fillConsultFields(sections) {
  const textareas = [...document.querySelectorAll('textarea')];
  const filled = [];
  textareas.forEach(ta => {
    const combined = (findLabel(ta) + ' ' + (ta.placeholder || '')).toLowerCase();
    let value = null;
    if (/histor|anamnes/.test(combined) && sections.history)           value = sections.history;
    else if (/finding|bevinding|onderzoek/.test(combined) && sections.findings) value = sections.findings;
    else if (/diagno/.test(combined) && sections.diagnosis)             value = sections.diagnosis;
    else if (/plan|therap|behandel/.test(combined) && sections.plan)   value = sections.plan;
    if (value !== null) {
      const ns = Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype, 'value').set;
      ns.call(ta, value);
      ta.dispatchEvent(new Event('input',  { bubbles: true }));
      ta.dispatchEvent(new Event('change', { bubbles: true }));
      ta.dispatchEvent(new Event('blur',   { bubbles: true }));
      ta.style.outline = '2px solid #2d5a3d';
      ta.style.outlineOffset = '1px';
      setTimeout(() => { ta.style.outline = ''; ta.style.outlineOffset = ''; }, 2500);
      filled.push(findLabel(ta) || ta.placeholder || 'field');
    }
  });
  return { filledCount: filled.length, fields: filled };
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === 'SCRAPE_PATIENT') {
    try { sendResponse({ success: true, data: scrapeCurrentFrame() }); }
    catch (e) { sendResponse({ success: false, error: e.message }); }
    return true;
  }
  if (msg.type === 'FILL_FIELDS') {
    try { sendResponse({ success: true, ...fillConsultFields(msg.sections) }); }
    catch (e) { sendResponse({ success: false, error: e.message }); }
    return true;
  }
  if (msg.type === 'PING') {
    sendResponse({ alive: true, url: window.location.href });
    return true;
  }
});
