// ─── State ──────────────────────────────────────────────────────────────────
let currentStyle = 'SOAP';
let patientData   = null;
let allTemplates  = [];
let editingTemplateId = null;
let currentTplField   = 'history';
let tplFieldData = { history:'', findings:'', diagnosis:'', plan:'' };
let activeTabId  = null;
let patientDisplayNum = ''; // e.g. "46599" — used as storage key

// ─── Default templates ───────────────────────────────────────────────────────
const DEFAULT_TEMPLATES = [
  {
    id: 'tpl_wellness', name: 'Wellness / Annual check-up', category: 'wellness',
    fields: {
      history:   'Owner presents {{name}} ({{species}}, {{age}}) for annual wellness examination. No current complaints. Reportedly healthy with normal appetite and activity.',
      findings:  'BAR. BCS [x/9]. T [°C], P [bpm], R [rpm], BW {{weight}}.\nSkin/coat: normal. Eyes/ears/nose: clear. Oral cavity: tartar grade [x]. Cardio: no murmurs. Resp: clear. Abdomen: soft, non-painful. LN: WNL. Gait: normal.',
      diagnosis: 'Healthy animal. No abnormalities detected on physical examination.',
      plan:      '- Vaccinations: [list]\n- Parasite prevention: [product]\n- Dental: [recommended/not yet]\n- Owner advice: [nutrition / weight / other]\n- Next annual check: 12 months',
    },
  },
  {
    id: 'tpl_gi', name: 'Gastrointestinal complaint', category: 'general',
    fields: {
      history:   'Owner presents {{name}} ({{species}}, {{age}}) with [vomiting/diarrhoea/inappetence] for [duration]. Frequency [x/day]. Character: [description]. Drinking: [normal/reduced]. Possible toxin/foreign body: [yes/no].',
      findings:  '[Alert/Depressed]. Dehydration: [none/mild/moderate]. T [°C], P [bpm], R [rpm], BW [kg].\nAbdomen: [soft/tense/painful]. Borborygmi: [normal/increased/absent]. MM: [pink/pale].',
      diagnosis: '[Acute gastroenteritis / Foreign body suspected / Pancreatitis / Other]',
      plan:      '- Anti-emetic: [drug, dose, route]\n- Fluids: [if indicated]\n- GI protectant: [drug, dose]\n- Bland diet [x] days\n- Diagnostics: [bloods/radiographs/US if needed]\n- Re-check [x] days if no improvement',
    },
  },
  {
    id: 'tpl_ortho', name: 'Lameness / Orthopaedic', category: 'orthopedic',
    fields: {
      history:   'Owner presents {{name}} ({{species}}, {{age}}) with [grade] lameness [R/L] [front/hind] for [duration]. Onset: [acute/gradual]. [Weight bearing / NWB]. Trauma history: [yes/no].',
      findings:  'Gait: grade [1-5] lameness [R/L] [front/hind].\n- Atrophy: [absent/mild/moderate/severe]\n- Swelling: [location]\n- Pain on palpation: [location]\n- ROM: [normal/reduced] — [joint]\n- Special tests: [result]',
      diagnosis: '[OA / Cruciate rupture / Fracture / Soft tissue injury / Patellar luxation / HD / Other]',
      plan:      '- Diagnostics: [radiographs/CT/joint tap]\n- NSAID: [drug, dose, duration]\n- Exercise restriction: [x] weeks\n- Physio: [yes/no]\n- Surgical referral: [if indicated]\n- Re-check: [x] weeks',
    },
  },
];

// ─── Init ────────────────────────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (tab) activeTabId = tab.id;

  await loadSettings();
  await loadTemplates();
  setupTabs();
  setupPills();
  setupHx();
  setupGenerate();
  setupTemplates();
  setupSettings();

  // Auto-scrape on open
  scrapePatient();
});

// ─── Tabs ────────────────────────────────────────────────────────────────────
function setupTabs() {
  document.querySelectorAll('.tab').forEach(tab => {
    tab.addEventListener('click', () => {
      document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
      document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
      tab.classList.add('active');
      document.getElementById('tab-' + tab.dataset.tab).classList.add('active');
    });
  });
}

// ─── Style pills ─────────────────────────────────────────────────────────────
function setupPills() {
  document.querySelectorAll('.pill').forEach(pill => {
    pill.addEventListener('click', () => {
      document.querySelectorAll('.pill').forEach(p => p.classList.remove('active'));
      pill.classList.add('active');
      currentStyle = pill.dataset.style;
    });
  });
}

// ─── Scrape patient — uses scripting.executeScript(allFrames:true) ────────────
// This is the key fix: we run JS directly inside every frame rather than
// relying on message passing, which doesn't reliably reach sub-frames.
async function scrapePatient() {
  setStatus('Scanning Animana…', false);
  document.getElementById('patientName').textContent = '—';
  document.getElementById('patientMeta').textContent = 'Scanning frames…';
  document.getElementById('historyBadge').classList.add('hidden');

  if (!activeTabId) { setStatus('No active tab', true); return; }

  try {
    // Inject the scraper function into every frame simultaneously
    const results = await chrome.scripting.executeScript({
      target: { tabId: activeTabId, allFrames: true },
      func: scrapeFrameContent,
    });

    // Score each frame result and pick the best one
    let best = null;
    let bestScore = 0;

    for (const r of results || []) {
      if (!r.result?.hasContent) continue;
      const score = scoreResult(r.result);
      if (score > bestScore) { bestScore = score; best = r.result; }
    }

    if (best && bestScore > 0) {
      patientData = best;
      if (best.clientId) patientClientId  = best.clientId;
      if (best.patientId) patientPatientId = best.patientId;
      if (best.patient?.displayNum) patientDisplayNum = best.patient.displayNum;
      renderPatientCard(best);
      restoreSavedNotes();
    } else {
      setStatus('No patient found — open a patient record in Animana', true);
      document.getElementById('patientName').textContent = 'No patient loaded';
      document.getElementById('patientMeta').textContent = 'Navigate to a patient file first';
    }
  } catch (err) {
    // Likely a permissions error — extension not allowed on this page yet
    setStatus('Cannot access page — reload Animana and try again', true);
    document.getElementById('patientMeta').textContent = err.message.substring(0, 80);
  }
}

// This function is serialised and injected into every frame by scripting API.
// It must be self-contained — no closures over outer variables.
function scrapeFrameContent() {
  const result = {
    frameUrl: window.location.href,
    hasContent: false,
    isConsultForm: false,
    patient: {},
    client: {},
    recentHistory: [],
  };

  const body = document.body;
  if (!body) return result;
  const text = body.innerText || '';
  if (text.trim().length < 30) return result;
  result.hasContent = true;

  // Detect consult form (4 textareas with placeholder text)
  const textareas = [...document.querySelectorAll('textarea')];
  const phText = textareas.map(t => (t.placeholder || '').toLowerCase()).join(' ');
  result.isConsultForm = textareas.length >= 2 && (
    /history|finding|diagnos|plan|anamnese|therap/i.test(phText) ||
    /GENERAL-CONSULT/i.test(text.substring(0, 800))
  );

  // Patient name: "Chloe (46599)"
  const nm = text.match(/\b([A-Z][a-z]{1,20})\s*\((\d{4,6})\)/);
  if (nm) { result.patient.name = nm[1]; result.patient.displayNum = nm[2]; }
  if (!result.patient.name) {
    const nm2 = text.match(/Patient:\s*([A-Z][a-z]{1,20})/);
    if (nm2) result.patient.name = nm2[1];
  }

  // Species + breed: "Canine   Papillon crossbreed"
  const sb = text.match(/(Canine|Feline|Avian|Rabbit|Rodent|Reptile|Equine|Bovine|Porcine)\s+([\w][\w\s]{1,40}?)(?=\n|female|male|$)/i);
  if (sb) {
    result.patient.species = sb[1];
    result.patient.breed   = sb[2].replace(/\s+/g, ' ').trim();
  }

  // Sex: "female spayed" on its own line
  const sx = text.match(/\b(female spayed|male castrated|male neutered|spayed female|neutered male|entire male|entire female|female intact|male intact|female|male)\b/i);
  if (sx) result.patient.sex = sx[1];

  // Age: "12 years and 3 months"
  const ag = text.match(/\d+\s+years?\s+and\s+\d+\s+months?/i) ||
             text.match(/\d+\s+years?/i) ||
             text.match(/\d+\s+months?\s+and\s+\d+\s+wks?/i);
  if (ag) result.patient.age = ag[0].trim();

  // Weight: "9.8 Kg"
  const wt = text.match(/\b(\d+\.?\d*)\s*[Kk]g\b/);
  if (wt) result.patient.weight = wt[1] + ' kg';

  // Microchip: "microchip number 528150002506770"
  const mc = text.match(/microchip\s+(?:number\s+)?(\d{10,20})/i) ||
             text.match(/\b(\d{15})\b/);
  if (mc) result.patient.microchip = mc[1];

  // Passport
  const pp = text.match(/passport\s+([A-Z]{2,4}\d{6,14})/i);
  if (pp) result.patient.passport = pp[1];

  // Client: "Dr. MD Rissik (Michael)"
  const cl = text.match(/Dr\.?\s+[A-Z]{1,3}\s+([A-Z][a-z]+)\s*\(/);
  if (cl) result.client.name = cl[1];

  // CPH: "CPH: 8638728"
  const cph = text.match(/CPH:\s*(\d{5,12})/i);
  if (cph) result.client.cph = cph[1];

  // Signalment line
  const sig = text.match(/Signalment:\s*([^\n]{10,150})/i);
  if (sig) result.patient.signalment = sig[1].trim();

  // ── Extract client + patient IDs for consult URL ──────────────────────────
  // Primary: Consult button onclick = redirectToActionUrl('consult', CLIENT_ID, PATIENT_ID)
  // This button appears when a patient row is selected in the Animals table
  const consultBtn = document.getElementById('main-action-consult');
  const consultOnclick = consultBtn?.getAttribute('onclick') || '';
  const idMatch = consultOnclick.match(/redirectToActionUrl\s*\(\s*'consult'\s*,\s*'([^']+)'\s*,\s*'([^']+)'\s*\)/);
  if (idMatch) {
    result.clientId  = idMatch[1];
    result.patientId = idMatch[2];
  } else {
    // Fallback: scan ALL onclick attributes for the redirectToActionUrl pattern
    const allOcEls = [...document.querySelectorAll('[onclick]')];
    for (const el of allOcEls) {
      const oc = el.getAttribute('onclick') || '';
      const m = oc.match(/redirectToActionUrl\s*\(\s*'consult'\s*,\s*'([^']+)'\s*,\s*'([^']+)'\s*\)/);
      if (m) { result.clientId = m[1]; result.patientId = m[2]; break; }
    }
    // Fallback 2: get client ID from the current page URL
    if (!result.clientId) {
      const urlMatch = window.location.href.match(/client\.id=([^&]+)/);
      if (urlMatch) result.clientId = urlMatch[1];
    }
    // Fallback 3: get patient ID from "Chloe (46599)" style — find in sidebar
    // patient.id can be found in any link on the page containing "patient.id="
    if (!result.patientId) {
      const patLink = [...document.querySelectorAll('a[href*="patient.id="]')][0];
      const pm = (patLink?.href || '').match(/patient\.id=([^&]+)/);
      if (pm) result.patientId = pm[1];
    }
  }

  // ── Scrape history from mana-date-spacer table ─────────────────────────
  // Confirmed DOM: tr.mana-date-spacer = date header (1 cell)
  //                tr (8 cells): [0]=checkbox [1]=type [2]=content [3]=vet initials
  const SKIP_TYPE = /^(uninvoiced|estimate|petscan|telefoon|phone|brief|letter|email|reminder|task|bijlage|attachment|overige)$/i;
  const dateHeaderRow = document.querySelector('tr.mana-date-spacer');
  const histTable = dateHeaderRow && dateHeaderRow.closest('table');

  if (histTable) {
    const rows = [...histTable.querySelectorAll('tr')];
    let currentDate = null;
    rows.forEach(row => {
      if ((row.getAttribute('class') || '').includes('mana-date-spacer')) {
        const m = (row.innerText || '').match(/(\d{2}-\d{2}-\d{4})/);
        if (m) currentDate = m[1];
        return;
      }
      if (!currentDate || !row.cells || row.cells.length < 3) return;
      const type    = (row.cells[1]?.innerText || '').trim();
      const content = (row.cells[2]?.innerText || '').trim();
      const vet     = (row.cells[3]?.innerText || '').trim();
      if (!type || SKIP_TYPE.test(type)) return;
      if (content.length < 20) return;
      if (/^time:\s*\d{2}:\d{2}$/.test(content)) return;
      result.recentHistory.push({ date: currentDate, type: type.toLowerCase(), content: content.substring(0, 800), vet });
    });
  }

  // Fallback: parse SOAP blocks from raw text if no table found
  if (!result.recentHistory.length) {
    const patterns = [
      ['Subjective', /Subjective:\n?([\s\S]{20,600}?)(?=\nObjective:|\nAssessment:|$)/i],
      ['Objective',  /Objective:\n?([\s\S]{20,600}?)(?=\nAssessment:|\nPlan:|$)/i],
      ['Assessment', /Assessment:\n?([\s\S]{10,400}?)(?=\nPlan:|$)/i],
      ['Plan',       /Plan:\n?([\s\S]{10,500}?)(?=\n\d{2}-\d{2}-\d{4}|\n[A-Z]|$)/i],
    ];
    patterns.forEach(([label, pat]) => {
      const m = text.match(pat);
      if (m && m[1].trim().length > 5)
        result.recentHistory.push({ date: 'recent', type: label.toLowerCase(), content: m[1].trim().substring(0, 500), vet: '' });
    });
  }

  return result;
}

function scoreResult(r) {
  let s = 0;
  if (r.patient?.name)      s += 10;
  if (r.patient?.species)   s += 5;
  if (r.patient?.breed)     s += 4;
  if (r.patient?.age)       s += 3;
  if (r.patient?.weight)    s += 3;
  if (r.patient?.sex)       s += 2;
  if (r.patient?.microchip) s += 2;
  if (r.client?.name)       s += 3;
  if (r.client?.cph)        s += 2;
  if (r.isConsultForm)      s += 5;
  s += (r.recentHistory?.length || 0) * 2;
  if (r.clientId && r.patientId) s += 8;
  // Bonus for entries with full clinical content
  if (r.recentHistory?.some(e => (e.content||e).length > 100)) s += 5;
  return s;
}

function renderPatientCard(data) {
  const { patient, client, recentHistory, isConsultForm } = data;

  // Name
  document.getElementById('patientName').textContent = patient.name || 'Unknown patient';

  // Meta line
  const metaParts = [
    patient.species,
    patient.breed,
    patient.sex,
    patient.age,
    patient.weight,
  ].filter(Boolean);
  document.getElementById('patientMeta').textContent =
    metaParts.join(' · ') || (patient.signalment || 'Details not found');

  // Status
  if (isConsultForm) {
    setStatus('✓ Consult form ready to fill', false);
    document.getElementById('pageStatus').style.color = 'var(--accent)';
  } else {
    setStatus('✓ Patient data loaded', false);
  }

  // History badge
  if (recentHistory?.length) {
    document.getElementById('historyBadge').classList.remove('hidden');
    document.getElementById('historyBadgeText').textContent =
      `${recentHistory.length} recent history entries loaded for AI context`;
  }
}

function setStatus(msg, isError) {
  const el = document.getElementById('pageStatus');
  el.textContent = msg;
  el.style.color = isError ? 'var(--danger)' : 'var(--text-muted)';
}

document.getElementById('refreshBtn').addEventListener('click', scrapePatient);

// ─── Autosave: Generate & Hx tabs ────────────────────────────────────────────

function notesKey() { return patientDisplayNum ? `notes_${patientDisplayNum}` : null; }
function hxKey()    { return patientDisplayNum ? `hx_${patientDisplayNum}`    : null; }

function showNotesStatus(msg, ok) {
  const el = document.getElementById('notesSaveStatus');
  if (!el) return;
  el.textContent = msg;
  el.style.color = ok ? 'var(--accent)' : 'var(--text-muted)';
}
function showHxStatus(msg, ok) {
  const el = document.getElementById('hxSaveStatus');
  if (!el) return;
  el.textContent = msg;
  el.style.color = ok ? 'var(--accent)' : 'var(--text-muted)';
}

async function saveGeneratedNotes(sections) {
  const key = notesKey();
  if (!key) return;
  const consultInput = document.getElementById('consultInput').value;
  const payload = {
    sections,
    consultInput,
    style: currentStyle,
    savedAt: new Date().toISOString(),
    patientName: patientData?.patient?.name || '',
  };
  try {
    await chrome.storage.local.set({ [key]: JSON.stringify(payload) });
    const t = new Date().toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' });
    showNotesStatus('✓ Notes saved at ' + t, true);
  } catch(e) { showNotesStatus('Save failed', false); }
}

async function saveHxSummary(summary) {
  const key = hxKey();
  if (!key) return;
  const payload = {
    summary,
    savedAt: new Date().toISOString(),
    patientName: patientData?.patient?.name || '',
  };
  try {
    await chrome.storage.local.set({ [key]: JSON.stringify(payload) });
    const t = new Date().toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' });
    showHxStatus('✓ Summary saved at ' + t, true);
  } catch(e) { showHxStatus('Save failed', false); }
}

async function restoreSavedNotes() {
  const nKey = notesKey();
  const hKey = hxKey();
  if (!nKey && !hKey) return;

  try {
    const result = await chrome.storage.local.get([nKey, hKey].filter(Boolean));

    // Restore generated notes
    if (nKey && result[nKey]) {
      const data = JSON.parse(result[nKey]);
      const s = data.sections || {};
      document.getElementById('fieldHistory').value   = s.history   || '';
      document.getElementById('fieldFindings').value  = s.findings  || '';
      document.getElementById('fieldDiagnosis').value = s.diagnosis || '';
      document.getElementById('fieldPlan').value      = s.plan      || '';
      if (data.consultInput) document.getElementById('consultInput').value = data.consultInput;
      document.getElementById('resultSection').classList.remove('hidden');
      const d = new Date(data.savedAt);
      showNotesStatus('✓ Previous notes loaded — saved ' + d.toLocaleDateString('en-GB') + ' ' +
        d.toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' }), true);
    }

    // Restore hx summary
    if (hKey && result[hKey]) {
      const data = JSON.parse(result[hKey]);
      if (data.summary) {
        // Update hx patient label
        document.getElementById('hxPatientLabel').textContent =
          (data.patientName || 'Patient') + ' — history';
        renderHxSummary(data.summary);
        showHxState('summary');
        const d = new Date(data.savedAt);
        showHxStatus('✓ Previous summary loaded — saved ' + d.toLocaleDateString('en-GB') + ' ' +
          d.toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' }), true);
      }
    }
  } catch(e) { /* silent — non-critical */ }
}

// ─── Generate ────────────────────────────────────────────────────────────────
function setupGenerate() {
  document.getElementById('generateBtn').addEventListener('click', generateNote);
  document.getElementById('fillAllBtn').addEventListener('click', fillAll);
  document.querySelectorAll('.field-fill-btn').forEach(btn => {
    btn.addEventListener('click', () => fillSingleField(btn.dataset.field));
  });
}

async function generateNote() {
  const consultInput = document.getElementById('consultInput').value.trim();
  if (!consultInput) { showError('Please describe the consultation first.'); return; }

  const { apiKey, systemPrompt } = await chrome.storage.local.get(['apiKey', 'systemPrompt']);
  if (!apiKey) { showError('No API key — click ⚙ to add your Anthropic API key.'); return; }

  clearError();
  document.getElementById('generateLoading').classList.remove('hidden');
  document.getElementById('generateBtn').disabled = true;
  document.getElementById('resultSection').classList.add('hidden');

  // Build rich patient context from scraped data
  let patientCtx = '';
  if (patientData) {
    const p = patientData.patient;
    const c = patientData.client;
    const lines = [
      p.name       && `Patient name: ${p.name}`,
      p.species    && `Species: ${p.species}`,
      p.breed      && `Breed: ${p.breed}`,
      p.sex        && `Sex: ${p.sex}`,
      p.age        && `Age: ${p.age}`,
      p.weight     && `Weight: ${p.weight}`,
      p.microchip  && `Microchip: ${p.microchip}`,
      p.signalment && `Signalment: ${p.signalment}`,
      c.name       && `Owner: ${c.name}`,
      c.cph        && `CPH: ${c.cph}`,
    ].filter(Boolean);
    if (lines.length) patientCtx += `PATIENT INFORMATION:\n${lines.join('\n')}\n\n`;

    if (patientData.recentHistory?.length) {
      const entries = patientData.recentHistory;
      // Group entries by date
      const byDate = {};
      entries.forEach(e => {
        const d = e.date || 'recent';
        if (!byDate[d]) byDate[d] = [];
        byDate[d].push(e);
      });
      let histText = 'PATIENT HISTORY FROM ANIMANA:\n';
      histText += '(Actively use this history to enrich the SOAP. Infer clinical context from product charges — e.g. medications dispensed imply diagnoses, dosages, and treatments administered. Mention relevant past diagnoses, ongoing conditions, weight trends, and previous procedures.)\n\n';
      Object.entries(byDate).forEach(([date, items]) => {
        histText += `[${date}]\n`;
        items.forEach(item => {
          const content = typeof item === 'string' ? item : (item.content || '');
          const type = typeof item === 'string' ? 'note' : (item.type || 'note');
          const vet = typeof item === 'string' ? '' : (item.vet ? ` (${item.vet})` : '');
          histText += `  ${type.toUpperCase()}${vet}:\n`;
          histText += `  ${content.replace(/\n/g, '\n  ')}\n`;
        });
        histText += '\n';
      });
      patientCtx += histText.substring(0, 4000) + '\n';
    }
  }

  const styleMap = {
    SOAP: `Write a structured SOAP note following these exact section guidelines. Use standard third-person, professional yet accessible prose. Improve medical terminology where necessary.

HISTORY (Subjective): Begin with the patient's name, age, breed, sex, and chief complaint. Elaborate on the history of the present illness including onset, duration, and any behavioural changes reported by the owner. Infer behavioural signs consistent with the likely diagnosis from the clinical context (e.g. oral pain behaviours from dental disease, polyuria/polydipsia from renal or endocrine disease).

FINDINGS (Objective): Structure into three subsections:
- Vitals: weight, temperature, heart rate, respiratory rate, MM, CRT. Use exact values if provided; use "within normal limits" if reported as normal.
- Clinical Findings: detailed physical examination findings.
- Further Diagnostics: summarise any laboratory results, imaging, or diagnostics performed. List abnormal parameters with measured values and reference ranges. If further tests were recommended or are pending, note this.

DIAGNOSIS (Assessment): Synthesise the subjective and objective information to reach a diagnosis or ranked list of differentials. Explain the clinical reasoning. Note any secondary or contributing problems identified.

PLAN: Detail all treatment steps with specific drug names, concentrations, calculated dosages, frequencies, and routes of administration. Derive doses from the patient's bodyweight where the drug and concentration are known. Include rationale for additional testing, client education provided, follow-up requirements, and specific aftercare instructions.`,

    narrative: 'Write professional, flowing narrative prose in third person appropriate for a veterinary medical record. Be clinically precise and include drug names and doses where applicable.',
    brief:     'Write concise clinical bullet-point notes. Be direct and efficient. Include specific drug names, doses, and frequencies.',
  };

  const defaultSystem = `You are a senior veterinary clinician writing medical records for IDEXX Animana practice management software.

Your task is to write a complete, high-quality SOAP note by synthesising ALL available information:
- The veterinarian's consultation notes (the primary source)
- The patient's signalment and history from Animana
- Products and treatments charged during the visit — these are critical: medications dispensed reveal diagnoses, drug choices, doses administered, and the clinical rationale. For example, Meloxidyl dispensed implies NSAID therapy for pain/inflammation; RC Recovery tins implies nutritional support for an anorexic patient; pre-anaesthetic protocol products imply a planned procedure.
- Previous history entries for context on chronic conditions, ongoing medications, and trends

Apply the following standards:
- Calculate drug doses from bodyweight where the drug name, concentration, and patient weight are available
- Use correct veterinary medical terminology throughout, improving any lay terms provided by the clinician
- Infer clinically logical behavioural signs consistent with the diagnosis (e.g. a patient with severe dental disease will show oral pain signs; document these even if not explicitly stated)
- Write in third person professional prose
- Use [value] placeholders only for measurements genuinely not available or inferable

Respond ONLY with a valid JSON object — no preamble, no markdown fences, no explanation outside the JSON.`;

  const userMsg =
    `${patientCtx}` +
    `CONSULTATION NOTES FROM VETERINARIAN:\n${consultInput}\n\n` +
    `INSTRUCTIONS: ${styleMap[currentStyle]}\n\n` +
    `Return ONLY this JSON object with exactly these four keys:\n` +
    `{\n  "history": "text for the History field",\n  "findings": "text for the Findings field",\n  "diagnosis": "text for the Diagnosis field",\n  "plan": "text for the Plan / Therapy field"\n}`;

  try {
    const resp = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': apiKey,
        'anthropic-version': '2023-06-01',
        'anthropic-dangerous-direct-browser-access': 'true',
      },
      body: JSON.stringify({
        model: 'claude-sonnet-4-20250514',
        max_tokens: 2500,
        system: systemPrompt || defaultSystem,
        messages: [{ role: 'user', content: userMsg }],
      }),
    });

    if (!resp.ok) {
      const e = await resp.json().catch(() => ({}));
      throw new Error(e.error?.message || `HTTP ${resp.status}`);
    }

    const data = await resp.json();
    const raw = data.content.map(b => b.text || '').join('').trim();

    let sections;
    try {
      const cleaned = raw.replace(/^```json\s*/i, '').replace(/^```\s*/i, '').replace(/```\s*$/, '').trim();
      sections = JSON.parse(cleaned);
    } catch {
      throw new Error('Could not parse AI response as JSON. Please try again.');
    }

    document.getElementById('fieldHistory').value   = sections.history   || '';
    document.getElementById('fieldFindings').value  = sections.findings  || '';
    document.getElementById('fieldDiagnosis').value = sections.diagnosis || '';
    document.getElementById('fieldPlan').value      = sections.plan      || '';
    document.getElementById('resultSection').classList.remove('hidden');

    // Auto-save generated notes
    await saveGeneratedNotes(sections);

  } catch (err) {
    showError('Error: ' + err.message);
  } finally {
    document.getElementById('generateLoading').classList.add('hidden');
    document.getElementById('generateBtn').disabled = false;
  }
}

// ─── Fill into Animana ────────────────────────────────────────────────────────
// Uses scripting.executeScript(allFrames:true) — same approach as scraping.
// The function runs in every frame; only the consult form frame will have
// matching textareas, so only that frame will fill anything.
async function fillAll() {
  await runFill({
    history:   document.getElementById('fieldHistory').value,
    findings:  document.getElementById('fieldFindings').value,
    diagnosis: document.getElementById('fieldDiagnosis').value,
    plan:      document.getElementById('fieldPlan').value,
  });
}

async function fillSingleField(field) {
  const map = { history:'fieldHistory', findings:'fieldFindings', diagnosis:'fieldDiagnosis', plan:'fieldPlan' };
  const value = document.getElementById(map[field])?.value;
  if (value) await runFill({ [field]: value });
}

async function runFill(sections) {
  if (!activeTabId) { showToast('No active tab'); return; }

  // ── Step 1: check if consult form is already open ───────────────────────
  const alreadyOpen = await isConsultFormOpen();

  if (!alreadyOpen) {
    // ── Step 2: try to open it automatically ──────────────────────────────
    const opened = await openConsultForm();
    if (!opened) {
      showToast('Could not open consult form — please click Consult in Animana first');
      return;
    }
    // ── Step 3: wait for the form to load ─────────────────────────────────
    setFillStatus('Opening consult form…');
    const ready = await waitForConsultForm(5000);
    if (!ready) {
      showToast('Consult form did not load in time — try clicking Fill again');
      setFillStatus('');
      return;
    }
  }

  // ── Step 4: inject the notes ───────────────────────────────────────────
  setFillStatus('Filling fields…');
  try {
    const results = await chrome.scripting.executeScript({
      target: { tabId: activeTabId, allFrames: true },
      func: fillFieldsInFrame,
      args: [sections],
    });
    const total = (results || []).reduce((sum, r) => sum + (r.result?.filledCount || 0), 0);
    if (total > 0) {
      showToast(`✓ Filled ${total} field${total !== 1 ? 's' : ''} into Animana`);
    } else {
      showToast('Fields not found — please try again');
    }
  } catch (err) {
    showToast('Error: ' + err.message);
  } finally {
    setFillStatus('');
  }
}

function setFillStatus(msg) {
  const btn = document.getElementById('fillAllBtn');
  if (btn) btn.textContent = msg || '✓ Fill all into Animana';
}

// Check if the consult form textareas are already visible in any frame
async function isConsultFormOpen() {
  try {
    const results = await chrome.scripting.executeScript({
      target: { tabId: activeTabId, allFrames: true },
      func: () => {
        const tas = [...document.querySelectorAll('textarea')];
        const phs = tas.map(t => (t.placeholder || '').toLowerCase()).join(' ');
        return /enter history|enter finding|enter diagnos|enter plan/i.test(phs) ||
               (/GENERAL-CONSULT/i.test(document.body?.innerText?.substring(0, 800) || '') && tas.length >= 2);
      },
    });
    return (results || []).some(r => r.result === true);
  } catch { return false; }
}

// Open the consult form — navigates the mana iframe to the consult form URL
async function openConsultForm() {
  const clientId  = patientClientId;
  const patientId = patientPatientId;

  // Strategy 1: navigate directly using stored IDs (fastest, most reliable)
  if (clientId && patientId) {
    try {
      await chrome.scripting.executeScript({
        target: { tabId: activeTabId, allFrames: false },
        func: (clientId, patientId) => {
          const manaFrame = document.getElementById('mana');
          if (!manaFrame) return false;
          const url = `https://rtdvelserbroek.animana.com/web2/patient/general-consult?generalConsultId=&patientId=${patientId}&clientId=${clientId}`;
          manaFrame.contentWindow.location.href = url;
          return true;
        },
        args: [clientId, patientId],
      });
      return true;
    } catch { /* fall through */ }
  }

  // Strategy 2: click the Consult button if it's visible
  try {
    const r1 = await chrome.scripting.executeScript({
      target: { tabId: activeTabId, allFrames: true },
      func: () => {
        const btn = document.getElementById('main-action-consult');
        if (btn) { btn.click(); return 'clicked-consult-btn'; }
        return null;
      },
    });
    if ((r1 || []).some(r => r.result === 'clicked-consult-btn')) return true;
  } catch { /* fall through */ }

  // Strategy 3: click the patient row to expose the Consult button, then click it
  // This handles the case where we're on the Animals tab but no patient is selected
  try {
    const r2 = await chrome.scripting.executeScript({
      target: { tabId: activeTabId, allFrames: true },
      func: (patientName) => {
        // Find and click the patient row by name
        const rows = [...document.querySelectorAll('tr')];
        const patRow = rows.find(r =>
          r.cells?.length > 1 && r.cells[0]?.innerText?.trim() === patientName
        );
        if (patRow) { patRow.cells[0].click(); return 'clicked-patient-row'; }
        return null;
      },
      args: [patientData?.patient?.name || ''],
    });

    if ((r2 || []).some(r => r.result === 'clicked-patient-row')) {
      // Wait for Consult button to appear, then click it
      await new Promise(res => setTimeout(res, 600));
      const r3 = await chrome.scripting.executeScript({
        target: { tabId: activeTabId, allFrames: true },
        func: () => {
          const btn = document.getElementById('main-action-consult');
          if (btn) { btn.click(); return true; }
          return false;
        },
      });
      if ((r3 || []).some(r => r.result === true)) return true;
    }
  } catch { /* fall through */ }

  return false;
}

// Poll until the consult form textareas appear (max waitMs)
async function waitForConsultForm(waitMs) {
  const start = Date.now();
  while (Date.now() - start < waitMs) {
    await new Promise(r => setTimeout(r, 400));
    if (await isConsultFormOpen()) return true;
  }
  return false;
}

// Self-contained function injected into every frame
function fillFieldsInFrame(sections) {
  function getLabel(ta) {
    if (ta.id) {
      const l = document.querySelector(`label[for="${ta.id}"]`);
      if (l) return l.textContent.trim();
    }
    let el = ta.previousElementSibling;
    while (el) {
      const t = el.textContent.trim();
      if (t && t.length < 80) return t;
      el = el.previousElementSibling;
    }
    const p = ta.parentElement;
    if (p) {
      const l = p.querySelector('label');
      if (l && !l.contains(ta)) return l.textContent.trim();
    }
    return ta.placeholder || ta.name || '';
  }

  const textareas = [...document.querySelectorAll('textarea')];
  if (!textareas.length) return { filledCount: 0, fields: [] };

  const filled = [];

  textareas.forEach((ta, idx) => {
    const combined = (getLabel(ta) + ' ' + (ta.placeholder || '')).toLowerCase();
    let value = null;

    // Label-based matching
    if (/histor|anamnes/.test(combined) && sections.history != null)        value = sections.history;
    else if (/finding|bevinding|onderzoek/.test(combined) && sections.findings != null) value = sections.findings;
    else if (/diagno/.test(combined) && sections.diagnosis != null)          value = sections.diagnosis;
    else if (/plan|therap|behandel/.test(combined) && sections.plan != null) value = sections.plan;

    // Positional fallback for 4-textarea forms
    if (value === null && textareas.length >= 4) {
      const pos = [sections.history, sections.findings, sections.diagnosis, sections.plan];
      if (idx < pos.length && pos[idx] != null) value = pos[idx];
    }

    if (value != null) {
      const setter = Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype, 'value').set;
      setter.call(ta, value);
      ta.dispatchEvent(new Event('input',  { bubbles: true }));
      ta.dispatchEvent(new Event('change', { bubbles: true }));
      ta.style.outline = '2px solid #2d5a3d';
      setTimeout(() => { ta.style.outline = ''; }, 2500);
      filled.push(getLabel(ta) || ta.placeholder || `textarea ${idx + 1}`);
    }
  });

  return { filledCount: filled.length, fields: filled };
}

// ─── Templates ────────────────────────────────────────────────────────────────
async function loadTemplates() {
  const { templates } = await chrome.storage.local.get('templates');
  allTemplates = templates || DEFAULT_TEMPLATES;
  if (!templates) await chrome.storage.local.set({ templates: DEFAULT_TEMPLATES });
  renderTemplates(allTemplates);
}

function renderTemplates(list) {
  const el = document.getElementById('templatesList');
  if (!list.length) {
    el.innerHTML = `<div class="empty-templates">No templates. Click <strong>+ New</strong>.</div>`;
    return;
  }
  el.innerHTML = list.map(t => `
    <div class="template-card">
      <div class="template-card-header">
        <div class="template-card-name">${esc(t.name)}</div>
        <div class="template-card-cat">${esc(t.category)}</div>
      </div>
      <div class="template-card-preview">${esc(Object.values(t.fields||{}).join(' ').substring(0,110))}…</div>
      <div class="template-card-actions">
        <button class="tpl-action-btn fill" data-action="fill" data-id="${t.id}">↳ Fill into Animana</button>
        <button class="tpl-action-btn"      data-action="edit" data-id="${t.id}">Edit</button>
        <button class="tpl-action-btn del"  data-action="delete" data-id="${t.id}">Delete</button>
      </div>
    </div>`).join('');

  el.querySelectorAll('[data-action]').forEach(btn => {
    btn.addEventListener('click', e => {
      const { action, id } = e.currentTarget.dataset;
      if (action === 'fill')   fillTemplate(id);
      if (action === 'edit')   openTemplateEditor(id);
      if (action === 'delete') deleteTemplate(id);
    });
  });
}

function setupTemplates() {
  document.getElementById('newTemplateBtn').addEventListener('click', () => openTemplateEditor(null));
  document.getElementById('cancelTemplateBtn').addEventListener('click', closeTemplateEditor);
  document.getElementById('saveTemplateBtn').addEventListener('click', saveTemplate);
  document.getElementById('templateSearch').addEventListener('input', e => {
    const q = e.target.value.toLowerCase();
    renderTemplates(allTemplates.filter(t =>
      t.name.toLowerCase().includes(q) || t.category.toLowerCase().includes(q)));
  });
  document.querySelectorAll('.tpl-tab').forEach(tab => {
    tab.addEventListener('click', () => {
      tplFieldData[currentTplField] = document.getElementById('tplFieldContent').value;
      document.querySelectorAll('.tpl-tab').forEach(t => t.classList.remove('active'));
      tab.classList.add('active');
      currentTplField = tab.dataset.tplField;
      document.getElementById('tplFieldContent').value = tplFieldData[currentTplField] || '';
    });
  });
}

function openTemplateEditor(id) {
  editingTemplateId = id;
  document.getElementById('templatesList').classList.add('hidden');
  document.querySelector('.templates-toolbar').classList.add('hidden');
  document.getElementById('templateEditor').classList.remove('hidden');
  if (id) {
    const t = allTemplates.find(x => x.id === id);
    document.getElementById('templateName').value = t.name;
    document.getElementById('templateCategory').value = t.category;
    tplFieldData = { history:'', findings:'', diagnosis:'', plan:'', ...(t.fields||{}) };
  } else {
    document.getElementById('templateName').value = '';
    document.getElementById('templateCategory').value = 'general';
    tplFieldData = { history:'', findings:'', diagnosis:'', plan:'' };
  }
  currentTplField = 'history';
  document.querySelectorAll('.tpl-tab').forEach(t => t.classList.remove('active'));
  document.querySelector('.tpl-tab[data-tpl-field="history"]').classList.add('active');
  document.getElementById('tplFieldContent').value = tplFieldData.history;
}

function closeTemplateEditor() {
  editingTemplateId = null;
  document.getElementById('templateEditor').classList.add('hidden');
  document.getElementById('templatesList').classList.remove('hidden');
  document.querySelector('.templates-toolbar').classList.remove('hidden');
}

async function saveTemplate() {
  tplFieldData[currentTplField] = document.getElementById('tplFieldContent').value;
  const name     = document.getElementById('templateName').value.trim();
  const category = document.getElementById('templateCategory').value;
  if (!name) { showToast('Enter a template name'); return; }
  if (editingTemplateId) {
    allTemplates = allTemplates.map(t =>
      t.id === editingTemplateId ? { ...t, name, category, fields: { ...tplFieldData } } : t);
  } else {
    allTemplates.push({ id: 'tpl_' + Date.now(), name, category, fields: { ...tplFieldData } });
  }
  await chrome.storage.local.set({ templates: allTemplates });
  renderTemplates(allTemplates);
  closeTemplateEditor();
  showToast('Template saved ✓');
}

async function deleteTemplate(id) {
  allTemplates = allTemplates.filter(t => t.id !== id);
  await chrome.storage.local.set({ templates: allTemplates });
  renderTemplates(allTemplates);
  showToast('Deleted');
}

async function fillTemplate(id) {
  const t = allTemplates.find(x => x.id === id);
  if (!t) return;
  const p = patientData?.patient || {};
  const rep = s => (s||'')
    .replace(/\{\{name\}\}/g,    p.name    || '{{name}}')
    .replace(/\{\{species\}\}/g, p.species || '{{species}}')
    .replace(/\{\{age\}\}/g,     p.age     || '{{age}}')
    .replace(/\{\{weight\}\}/g,  p.weight  || '{{weight}}');
  await runFill({
    history:   rep(t.fields?.history),
    findings:  rep(t.fields?.findings),
    diagnosis: rep(t.fields?.diagnosis),
    plan:      rep(t.fields?.plan),
  });
}

// ─── Settings ─────────────────────────────────────────────────────────────────
async function loadSettings() {
  const { apiKey, systemPrompt } = await chrome.storage.local.get(['apiKey', 'systemPrompt']);
  if (apiKey)       document.getElementById('apiKeyInput').value       = apiKey;
  if (systemPrompt) document.getElementById('systemPromptInput').value = systemPrompt;
}

function setupSettings() {
  document.getElementById('settingsBtn').addEventListener('click', () =>
    document.getElementById('settingsPanel').classList.remove('hidden'));
  document.getElementById('backBtn').addEventListener('click', () =>
    document.getElementById('settingsPanel').classList.add('hidden'));
  document.getElementById('toggleKeyBtn').addEventListener('click', () => {
    const inp = document.getElementById('apiKeyInput');
    const btn = document.getElementById('toggleKeyBtn');
    inp.type = inp.type === 'password' ? 'text' : 'password';
    btn.textContent = inp.type === 'password' ? 'Show' : 'Hide';
  });
  document.getElementById('saveApiKeyBtn').addEventListener('click', async () => {
    await chrome.storage.local.set({ apiKey: document.getElementById('apiKeyInput').value.trim() });
    showToast('API key saved ✓');
  });
  document.getElementById('savePromptBtn').addEventListener('click', async () => {
    await chrome.storage.local.set({ systemPrompt: document.getElementById('systemPromptInput').value.trim() });
    showToast('Prompt saved ✓');
  });
}

// ─── Helpers ──────────────────────────────────────────────────────────────────
function showError(msg) {
  const el = document.getElementById('generateError');
  el.textContent = msg;
  el.classList.remove('hidden');
}
function clearError() { document.getElementById('generateError').classList.add('hidden'); }
function showToast(msg) {
  document.querySelector('.toast')?.remove();
  const t = document.createElement('div');
  t.className = 'toast'; t.textContent = msg;
  document.body.appendChild(t);
  setTimeout(() => t.remove(), 2300);
}
function esc(s) {
  return (s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

// ══════════════════════════════════════════════════════════
// ── PATIENT HX TAB ────────────────────────────────────────
// ══════════════════════════════════════════════════════════

function setupHx() {
  document.getElementById('summariseBtn').addEventListener('click', runSummarise);
}

// Collect ALL history entries from the page — including weight/product rows for full context
function collectFullHistory() {
  const SKIP = /^(petscan|telefoon|phone|brief|letter|email|reminder|task|bijlage|attachment|overige)$/i;

  return chrome.scripting.executeScript({
    target: { tabId: activeTabId, allFrames: true },
    func: () => {
      const SKIP = /^(petscan|telefoon|phone|brief|letter|email|reminder|task|bijlage|attachment|overige)$/i;
      const dateRow = document.querySelector('tr.mana-date-spacer');
      const histTable = dateRow?.closest('table');
      if (!histTable) return null;

      const rows = [...histTable.querySelectorAll('tr')];
      let currentDate = null;
      const entries = [];

      rows.forEach(row => {
        if ((row.getAttribute('class') || '').includes('mana-date-spacer')) {
          const m = (row.innerText || '').match(/(\d{2}-\d{2}-\d{4})/);
          if (m) currentDate = m[1];
          return;
        }
        if (!currentDate || !row.cells || row.cells.length < 3) return;
        const type    = (row.cells[1]?.innerText || '').trim();
        const content = (row.cells[2]?.innerText || '').trim();
        const vet     = (row.cells[3]?.innerText || '').trim();
        if (!type || SKIP.test(type) || content.length < 3) return;
        if (/^time:\s*\d{2}:\d{2}$/.test(content)) return;
        entries.push({ date: currentDate, type: type.toLowerCase(), content, vet });
      });

      return entries.length ? entries : null;
    },
  }).then(results => {
    for (const r of results || []) {
      if (r?.result) return r.result;
    }
    return null;
  });
}

async function runSummarise() {
  const { apiKey } = await chrome.storage.local.get('apiKey');
  if (!apiKey) { showHxError('No API key — click ⚙ to add your Anthropic API key.'); return; }

  // Update header label
  const name = patientData?.patient?.name;
  const species = [patientData?.patient?.species, patientData?.patient?.breed].filter(Boolean).join(' ');
  document.getElementById('hxPatientLabel').textContent = name
    ? `${name} — ${species}`
    : 'Patient history';

  showHxState('loading');
  document.getElementById('summariseBtn').disabled = true;

  try {
    // Collect history from all frames
    const entries = await collectFullHistory();

    if (!entries || !entries.length) {
      showHxError('No history found — make sure you are on the patient history page in Animana.');
      return;
    }

    // Show date range
    const dates = [...new Set(entries.map(e => e.date))];
    document.getElementById('hxDateRange').textContent =
      `${dates[dates.length - 1]} → ${dates[0]} · ${entries.length} entries`;

    // Build the text to send to AI — structured by date
    const byDate = {};
    entries.forEach(e => {
      if (!byDate[e.date]) byDate[e.date] = [];
      byDate[e.date].push(e);
    });

    let historyText = '';
    Object.entries(byDate).forEach(([date, items]) => {
      historyText += `\n[${date}]\n`;
      items.forEach(item => {
        historyText += `  ${item.type.toUpperCase()}${item.vet ? ` (${item.vet})` : ''}:\n`;
        historyText += `  ${item.content.replace(/\n/g, '\n  ')}\n`;
      });
    });

    // Patient info preamble
    const p = patientData?.patient || {};
    const patientInfo = [
      p.name       && `Patient: ${p.name}`,
      p.signalment || [p.species, p.breed, p.sex, p.age].filter(Boolean).join(', '),
      p.weight     && `Weight: ${p.weight}`,
    ].filter(Boolean).join(' | ');

    const systemPrompt = `You are a veterinary clinical assistant. Analyse patient history records and produce a concise structured summary a vet can read in 60 seconds before a consultation.

Respond with ONLY valid JSON — no markdown, no preamble. Use this exact structure:
{
  "vitals": [
    { "label": "Weight", "value": "9.8 kg" },
    { "label": "Last visit", "value": "01-04-2026" }
  ],
  "sections": [
    {
      "title": "Section title",
      "icon": "🔴|🟡|🟢|💊|🦷|🦴|🫀|🧪|📋",
      "colour": "red|amber|green|blue|purple|grey",
      "badge": "optional short badge e.g. Ongoing",
      "body": "2-4 sentence summary. Be clinical and concise."
    }
  ],
  "generatedAt": "ISO timestamp"
}

Section guidelines:
- Use "red" colour for active problems, urgent issues, or abnormal findings
- Use "amber" for chronic conditions, ongoing medications, or monitoring items
- Use "green" for resolved issues or normal findings
- Use "blue" for diagnostics, lab results, imaging
- Use "purple" for surgical history or procedures
- Use "grey" for administrative or vaccination records
- Always include an "Active Problems / Concerns" section first if there are any
- Include a "Current Medications" section if any drugs are ongoing
- Include a "Surgical / Procedure History" section if relevant
- Include a "Vaccination & Preventive Care" section
- Include a "Trends" section noting weight changes, recurring issues, or patterns
- Keep each body to 2-4 sentences maximum. Prioritise clinical relevance.`;

    const userMsg = `${patientInfo ? `PATIENT: ${patientInfo}\n\n` : ''}HISTORY RECORDS:\n${historyText}`;

    const resp = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': apiKey,
        'anthropic-version': '2023-06-01',
        'anthropic-dangerous-direct-browser-access': 'true',
      },
      body: JSON.stringify({
        model: 'claude-sonnet-4-20250514',
        max_tokens: 1800,
        system: systemPrompt,
        messages: [{ role: 'user', content: userMsg }],
      }),
    });

    if (!resp.ok) {
      const err = await resp.json().catch(() => ({}));
      throw new Error(err.error?.message || `API error ${resp.status}`);
    }

    const data = await resp.json();
    const raw  = data.content.map(b => b.text || '').join('').trim();
    const clean = raw.replace(/^```json\s*/i, '').replace(/^```\s*/i, '').replace(/```\s*$/, '').trim();

    let summary;
    try { summary = JSON.parse(clean); }
    catch { throw new Error('Could not parse AI response. Please try again.'); }

    renderHxSummary(summary);
    showHxState('summary');

    // Auto-save hx summary
    await saveHxSummary(summary);

  } catch (e) {
    showHxError('Error: ' + e.message);
  } finally {
    document.getElementById('summariseBtn').disabled = false;
  }
}

function renderHxSummary(summary) {
  // Vitals strip
  const vitalsEl = document.getElementById('hxVitals');
  vitalsEl.innerHTML = (summary.vitals || []).map(v => `
    <div class="hx-vital-pill">
      <span class="vital-label">${esc(v.label)}</span>
      <span>${esc(v.value)}</span>
    </div>
  `).join('');

  // Sections
  const sectionsEl = document.getElementById('hxSections');
  sectionsEl.innerHTML = (summary.sections || []).map((s, i) => `
    <div class="hx-section" id="hxSection${i}">
      <div class="hx-section-header" onclick="toggleHxSection(${i})">
        <div class="hx-section-icon icon-${esc(s.colour || 'grey')}">${s.icon || '📋'}</div>
        <span class="hx-section-title">${esc(s.title)}</span>
        ${s.badge ? `<span class="hx-section-badge">${esc(s.badge)}</span>` : ''}
        <svg class="hx-section-chevron" width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="6 9 12 15 18 9"/></svg>
      </div>
      <div class="hx-section-body">${esc(s.body)}</div>
    </div>
  `).join('');

  // Footer with timestamp + regenerate button
  const ts = summary.generatedAt
    ? new Date(summary.generatedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    : new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

  const existingFooter = document.getElementById('hxFooter');
  if (existingFooter) existingFooter.remove();

  const footer = document.createElement('div');
  footer.id = 'hxFooter';
  footer.className = 'hx-footer';
  footer.innerHTML = `
    <span class="hx-generated-at">Generated at ${ts}</span>
    <button class="btn-regen" onclick="runSummarise()">↺ Regenerate</button>
  `;
  document.getElementById('hxSummary').appendChild(footer);
}

function toggleHxSection(i) {
  const section = document.getElementById(`hxSection${i}`);
  section?.classList.toggle('collapsed');
}

function showHxState(state) {
  document.getElementById('hxLoading').classList.toggle('hidden', state !== 'loading');
  document.getElementById('hxError').classList.add('hidden');
  document.getElementById('hxEmpty').classList.toggle('hidden', state !== 'empty');
  document.getElementById('hxSummary').classList.toggle('hidden', state !== 'summary');
}

function showHxError(msg) {
  document.getElementById('hxLoading').classList.add('hidden');
  document.getElementById('hxEmpty').classList.add('hidden');
  document.getElementById('hxSummary').classList.add('hidden');
  const el = document.getElementById('hxError');
  el.textContent = msg;
  el.classList.remove('hidden');
}

// Make toggleHxSection and runSummarise accessible from inline onclick
window.toggleHxSection = toggleHxSection;
window.runSummarise = runSummarise;
