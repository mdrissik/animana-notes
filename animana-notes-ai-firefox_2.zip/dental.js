// ── Animana Dental Chart v5.0 ─────────────────────────────────────────────
// Horizontal layout matching Ranzijn chart
// Quadrant CI/GI/PI presets, Extracted-during-procedure flag

(function(){
'use strict';

// ── Score keys ────────────────────────────────────────────────────────────
const SCORE_KEYS = ['CI','GI','PI','F','M','R'];
const FLAG_KEYS  = ['Miss','Ext'];
const ALL_KEYS   = [...SCORE_KEYS,...FLAG_KEYS];

const CYCLE = {
  CI:  ['','0','1','2','3'],
  GI:  ['','0','1','2','3'],
  PI:  ['','0','1','2','3'],
  F:   ['','F1','F2','F3'],
  M:   ['','M1','M2','M3'],
  R:   ['','1','2','3','4','5'],
  Miss:['','Miss'],
  Ext: ['','Ext'],
};
function cyc(k,cur){const a=CYCLE[k];return a[(a.indexOf(cur||'')+1)%a.length];}

// Grade CSS class
const GC = {
  CI:  {'0':'g0','1':'g1','2':'g2','3':'g3'},
  GI:  {'0':'g0','1':'g1','2':'g2','3':'g3'},
  PI:  {'0':'g0','1':'g1','2':'g2','3':'g3'},
  F:   {'F1':'g1','F2':'g2','F3':'g3'},
  M:   {'M1':'g1','M2':'g2','M3':'g3'},
  R:   {'1':'g1','2':'g1','3':'g2','4':'g3','5':'g3'},
  Miss:{'Miss':'gmiss'},
  Ext: {'Ext':'gext'},
};
function gc(k,v){return GC[k]&&GC[k][v]||'';}

const FURC = new Set([
  '105','106','107','108','109','110',
  '205','206','207','208','209','210',
  '305','306','307','308','309','310',
  '405','406','407','408','409','410',
]);

const DESCRIPTIONS = {
  CI:{label:'Calculus Index (CI)',scores:{'0':'No calculus','1':'Supragingival calculus covering <1/3 buccal surface','2':'Moderate calculus covering 1/3–2/3 buccal surface with minimal subgingival deposit','3':'Heavy calculus covering >2/3 buccal surface extending subgingivally'}},
  GI:{label:'Gingival Index (GI)',scores:{'0':'Normal gingiva','1':'Marginal gingivitis, mild swelling, colour change, no BOP','2':'Moderate swelling and inflammation, BOP','3':'Marked swelling and inflammation, spontaneous bleeding'}},
  PI:{label:'Plaque Index (PI)',scores:{'0':'No plaque','1':'Thin film covering <1/3 buccal surface','2':'Moderate plaque covering 1/3–2/3 buccal surface','3':'Abundant soft plaque covering >2/3 buccal surface'}},
  F: {label:'Furcation (F) — multi-rooted teeth only',scores:{'F1':'Probe enters furcation up to 1/3 buccolingual crown width','F2':'Probe enters up to 2/3 buccolingual crown width','F3':'Probe passes all the way through buccolingual crown width'}},
  M: {label:'Tooth Mobility (M)',scores:{'M1':'Slight mobility >0.2mm, <0.5mm','M2':'Moderate mobility >0.5mm, <1mm in any lateral direction','M3':'Severe mobility >1mm or tooth intruded/extruded from socket'}},
  R: {label:'Tooth Resorption (R)',scores:{'1':'Lesion in enamel/cementum only','2':'Penetration into dentine','3':'Penetration deeper into dentine, close to pulp','4':'Significant coronal tooth loss','5':'Crown lost'}},
};

// ── Tooth data ────────────────────────────────────────────────────────────
// Left side of chart = Patient's RHS (100s maxilla, 400s mandible)
// Right side of chart = Patient's LHS (200s maxilla, 300s mandible)
// maxL: RHS maxilla, outer→inner (110→101)
// maxR: LHS maxilla, inner→outer (201→210)
// manL: RHS mandible, outer→inner (411→401)
// manR: LHS mandible, inner→outer (301→311)

const TEETH = {
  canine:{
    // null = absent tooth — renders as blank column to balance upper (10) with lower (11)
    maxL:[null,'110','109','108','107','106','105','104','103','102','101'],
    maxR:['201','202','203','204','205','206','207','208','209','210',null],
    manL:['411','410','409','408','407','406','405','404','403','402','401'],
    manR:['301','302','303','304','305','306','307','308','309','310','311'],
    q:{'1':['101','102','103','104','105','106','107','108','109','110'],
       '2':['201','202','203','204','205','206','207','208','209','210'],
       '3':['301','302','303','304','305','306','307','308','309','310','311'],
       '4':['401','402','403','404','405','406','407','408','409','410','411']},
    t:{'101':'I','102':'I','103':'I','104':'C','105':'P','106':'P','107':'P','108':'P4',
       '109':'M','110':'M','201':'I','202':'I','203':'I','204':'C','205':'P','206':'P',
       '207':'P','208':'P4','209':'M','210':'M',
       '401':'I','402':'I','403':'I','404':'C','405':'P','406':'P','407':'P','408':'P4',
       '409':'M','410':'M','411':'M',
       '301':'I','302':'I','303':'I','304':'C','305':'P','306':'P','307':'P','308':'P4',
       '309':'M','310':'M','311':'M'},
  },
  feline:{
    maxL:['109','108','107','106','104','103','102','101'],
    maxR:['201','202','203','204','206','207','208','209'],
    // null = absent PM2 — renders as blank column to balance lower (7) with upper (8)
    manL:['409','408','407',null,'404','403','402','401'],
    manR:['301','302','303','304',null,'307','308','309'],
    q:{'1':['101','102','103','104','106','107','108','109'],
       '2':['201','202','203','204','206','207','208','209'],
       '3':['301','302','303','304','307','308','309'],
       '4':['401','402','403','404','407','408','409']},
    t:{'101':'I','102':'I','103':'I','104':'C','106':'P','107':'P','108':'P4','109':'M',
       '201':'I','202':'I','203':'I','204':'C','206':'P','207':'P','208':'P4','209':'M',
       '401':'I','402':'I','403':'I','404':'C','407':'P','408':'P4','409':'M',
       '301':'I','302':'I','303':'I','304':'C','307':'P','308':'P4','309':'M'},
  },
};

// Tooth shape height in shape row (px)
const TOOTH_H = {'I':10,'C':20,'P':14,'P4':20,'M':18};
const TOOTH_W = {'I':10,'C':12,'P':14,'P4':18,'M':18};

// ── State ─────────────────────────────────────────────────────────────────
let dcSpecies  = 'canine';
let dcFindings = {};
let dcPatientNum = '';

function getF(id){return dcFindings[id]||{};}

// ── Persistence ───────────────────────────────────────────────────────────
function storageKey(){return dcPatientNum?`dental_${dcPatientNum}`:null;}

function showSaveStatus(msg,cls){
  const el=document.getElementById('dcSaveStatus');
  if(!el)return;
  el.textContent=msg;
  el.className='dc-save-status '+(cls||'');
}

async function dcAutoSave(){
  const key=storageKey();
  if(!key)return;
  showSaveStatus('Saving…','saving');
  const reportEl=document.getElementById('dcReportArea');
  const payload={
    species:dcSpecies, findings:dcFindings,
    report:reportEl?reportEl.value:'',
    savedAt:new Date().toISOString(),
    patientName:(document.getElementById('dcPatientName')||{}).value||'',
    ownerSurname:(document.getElementById('dc_owner')||{}).value||'',
  };
  try{
    await chrome.storage.local.set({[key]:JSON.stringify(payload)});
    const t=new Date().toLocaleTimeString('en-GB',{hour:'2-digit',minute:'2-digit'});
    showSaveStatus('✓ Saved at '+t,'saved');
  }catch(e){showSaveStatus('Save failed','');}
}

async function dcLoadFromStorage(num){
  if(!num)return false;
  try{
    const result=await chrome.storage.local.get(`dental_${num}`);
    const raw=result[`dental_${num}`];
    if(!raw)return false;
    const data=JSON.parse(raw);
    if(data.species)dcSpecies=data.species;
    dcFindings=data.findings||{};
    dcRenderCharts();
    buildQuadPanel();
    const reportEl=document.getElementById('dcReportArea');
    const wrapEl=document.getElementById('dcReportWrap');
    if(reportEl&&data.report){reportEl.value=data.report;if(wrapEl)wrapEl.classList.remove('hidden');}
    if(data.savedAt){
      const d=new Date(data.savedAt);
      showSaveStatus('✓ Previous chart loaded — last saved '+d.toLocaleDateString('en-GB')+' '+d.toLocaleTimeString('en-GB',{hour:'2-digit',minute:'2-digit'}),'saved');
    }
    return true;
  }catch(e){return false;}
}

async function dcClearChart(){
  if(!confirm('Clear all charting and report for this patient? This cannot be undone.'))return;
  const key=storageKey();
  if(key){try{await chrome.storage.local.remove(key);}catch(e){}}
  dcFindings={};
  dcRenderCharts();
  buildQuadPanel();
  const reportEl=document.getElementById('dcReportArea');
  const wrapEl=document.getElementById('dcReportWrap');
  if(reportEl)reportEl.value='';
  if(wrapEl)wrapEl.classList.add('hidden');
  showSaveStatus('Chart cleared','');
}

// ── Tooth colour for shape row ─────────────────────────────────────────────
function toothColor(id){
  const f=getF(id);
  if(f.Miss==='Miss')return'#B4B2A9';
  if(f.Ext==='Ext')return'#7aaed6';
  const vals=SCORE_KEYS.map(k=>f[k]||'').filter(Boolean);
  if(!vals.length)return'#fff';
  const worst=v=>['3','F3','M3','4','5'].includes(v)?3:['2','F2','M2'].includes(v)?2:v&&v!=='0'?1:0;
  const max=Math.max(...vals.map(worst));
  if(max>=3)return'#F09595';
  if(max===2)return'#FAC775';
  if(max>=1)return'#9FE1CB';
  return'#9FE1CB';
}

// ── Build score cell <td> ─────────────────────────────────────────────────
function makeScoreTd(id,key){
  const f=getF(id);
  const absent=f.Miss==='Miss';
  const isNA=key==='F'&&!FURC.has(id);
  const td=document.createElement('td');
  td.className='dc-score-td';
  td.dataset.id=id;td.dataset.key=key;

  if(isNA){td.classList.add('dc-na');return td;}
  if(absent&&key!=='Miss'&&key!=='Ext'){td.classList.add('dc-greyed');return td;}

  const val=f[key]||'';
  if(val){const g=gc(key,val);if(g)td.classList.add(g);td.textContent=val;}

  td.addEventListener('click',()=>{
    if(!dcFindings[id])dcFindings[id]={};
    dcFindings[id][key]=cyc(key,dcFindings[id][key]);
    // Miss and Ext are mutually exclusive
    if(key==='Miss'&&dcFindings[id].Miss==='Miss')dcFindings[id].Ext='';
    if(key==='Ext'&&dcFindings[id].Ext==='Ext')dcFindings[id].Miss='';
    dcRenderCharts();
    dcAutoSave();
  });
  return td;
}

// ── Build jaw table ────────────────────────────────────────────────────────
function buildJawTable(isUpper, leftTeeth, rightTeeth, jawLabel){
  const tbl=document.createElement('table');
  tbl.className='dc-jaw-table dc-jaw-'+(isUpper?'upper':'lower');
  const tb=document.createElement('tbody');

  function numRow(){
    const tr=document.createElement('tr');
    tr.className='dc-num-row';
    const lbl=document.createElement('td');lbl.className='dc-row-label';tr.appendChild(lbl);
    leftTeeth.forEach(id=>{
      const td=document.createElement('td');
      if(id===null){td.className='dc-num-cell dc-blank';}
      else{td.className='dc-num-cell';td.textContent=id;}
      tr.appendChild(td);
    });
    const ct=document.createElement('td');ct.className='dc-center-label';ct.textContent=jawLabel;tr.appendChild(ct);
    rightTeeth.forEach(id=>{
      const td=document.createElement('td');
      if(id===null){td.className='dc-num-cell dc-blank';}
      else{td.className='dc-num-cell';td.textContent=id;}
      tr.appendChild(td);
    });
    const rlbl=document.createElement('td');rlbl.className='dc-row-label-right';tr.appendChild(rlbl);
    return tr;
  }

  function shapeRow(){
    const tr=document.createElement('tr');tr.className='dc-shape-row';
    const lbl=document.createElement('td');lbl.className='dc-row-label';tr.appendChild(lbl);
    leftTeeth.forEach(id=>{
      const td=document.createElement('td');
      if(id===null){td.className='dc-shape-cell dc-blank';tr.appendChild(td);return;}
      td.className='dc-shape-cell';
      const d=TEETH[dcSpecies];const t=d.t[id]||'I';
      const w=TOOTH_W[t]||12,h=TOOTH_H[t]||12,fill=toothColor(id);
      const rx=t==='I'?2:t==='C'?3:4;
      td.innerHTML=`<svg width="${w}" height="${h}" viewBox="0 0 ${w} ${h}" style="display:block;margin:0 auto"><rect x="1" y="1" width="${w-2}" height="${h-2}" rx="${rx}" fill="${fill}" stroke="#aaa" stroke-width="0.7"/></svg>`;
      tr.appendChild(td);
    });
    const ct=document.createElement('td');ct.className='dc-center-label';tr.appendChild(ct);
    rightTeeth.forEach(id=>{
      const td=document.createElement('td');
      if(id===null){td.className='dc-shape-cell dc-blank';tr.appendChild(td);return;}
      td.className='dc-shape-cell';
      const d=TEETH[dcSpecies];const t=d.t[id]||'I';
      const w=TOOTH_W[t]||12,h=TOOTH_H[t]||12,fill=toothColor(id);
      const rx=t==='I'?2:t==='C'?3:4;
      td.innerHTML=`<svg width="${w}" height="${h}" viewBox="0 0 ${w} ${h}" style="display:block;margin:0 auto"><rect x="1" y="1" width="${w-2}" height="${h-2}" rx="${rx}" fill="${fill}" stroke="#aaa" stroke-width="0.7"/></svg>`;
      tr.appendChild(td);
    });
    const rlbl=document.createElement('td');rlbl.className='dc-row-label-right';tr.appendChild(rlbl);
    return tr;
  }

  function scoreRow(key){
    const tr=document.createElement('tr');
    tr.className='dc-score-row dc-row-'+key.toLowerCase();
    const lbl=document.createElement('td');lbl.className='dc-row-label';lbl.textContent=key;tr.appendChild(lbl);
    leftTeeth.forEach(id=>{
      if(id===null){const td=document.createElement('td');td.className='dc-score-td dc-blank';tr.appendChild(td);return;}
      tr.appendChild(makeScoreTd(id,key));
    });
    const ct=document.createElement('td');ct.className='dc-center-label';tr.appendChild(ct);
    rightTeeth.forEach(id=>{
      if(id===null){const td=document.createElement('td');td.className='dc-score-td dc-blank';tr.appendChild(td);return;}
      tr.appendChild(makeScoreTd(id,key));
    });
    const rlbl=document.createElement('td');rlbl.className='dc-row-label-right';rlbl.textContent=key;tr.appendChild(rlbl);
    return tr;
  }

  if(isUpper){
    // Upper: score rows inverted (CI closest to teeth at bottom, Ext furthest)
    [...ALL_KEYS].reverse().forEach(k=>tb.appendChild(scoreRow(k)));
    tb.appendChild(shapeRow());
    tb.appendChild(numRow());
  } else {
    // Lower: numbers, shape, then score rows
    tb.appendChild(numRow());
    tb.appendChild(shapeRow());
    ALL_KEYS.forEach(k=>tb.appendChild(scoreRow(k)));
  }

  tbl.appendChild(tb);return tbl;
}

// ── Render charts ─────────────────────────────────────────────────────────
function dcRenderCharts(){
  const d=TEETH[dcSpecies];
  const outer=document.getElementById('dcChartOuter');
  if(!outer)return;
  outer.innerHTML='';

  // Upper jaw
  const upperSec=document.createElement('div');upperSec.className='dc-jaw-section';
  const upperHdr=document.createElement('div');upperHdr.className='dc-jaw-header';
  upperHdr.innerHTML='<span>Right — RHS</span><span style="color:var(--accent);font-size:10px">UPPER JAW</span><span>Left — LHS</span>';
  upperSec.appendChild(upperHdr);
  upperSec.appendChild(buildJawTable(true,d.maxL,d.maxR,'UPPER'));
  outer.appendChild(upperSec);

  const sep=document.createElement('div');sep.className='dc-jaw-sep';outer.appendChild(sep);

  // Lower jaw
  const lowerSec=document.createElement('div');lowerSec.className='dc-jaw-section';
  lowerSec.appendChild(buildJawTable(false,d.manL,d.manR,'LOWER'));
  const lowerHdr=document.createElement('div');lowerHdr.className='dc-jaw-header';
  lowerHdr.innerHTML='<span>Right — RHS</span><span style="color:var(--accent);font-size:10px">LOWER JAW</span><span>Left — LHS</span>';
  lowerSec.appendChild(lowerHdr);
  outer.appendChild(lowerSec);
}

// ── Quadrant preset panel ─────────────────────────────────────────────────
function buildQuadPanel(){
  const panel=document.getElementById('dcQuadPanel');
  if(!panel)return;
  panel.innerHTML='';

  const title=document.createElement('div');
  title.className='dc-quad-panel-title';
  title.textContent='Quadrant presets — set CI / GI / PI for all teeth in a quadrant';
  panel.appendChild(title);

  const d=TEETH[dcSpecies];
  const quads=[
    {num:'1',label:'Q1 — Right Upper',teeth:d.q['1']},
    {num:'2',label:'Q2 — Left Upper', teeth:d.q['2']},
    {num:'4',label:'Q4 — Right Lower',teeth:d.q['4']},
    {num:'3',label:'Q3 — Left Lower', teeth:d.q['3']},
  ];

  const grid=document.createElement('div');grid.className='dc-quad-grid';

  quads.forEach(q=>{
    const row=document.createElement('div');row.className='dc-quad-row';
    const lbl=document.createElement('span');lbl.className='dc-quad-label';lbl.textContent=q.label;row.appendChild(lbl);

    ['CI','GI','PI'].forEach(key=>{
      const klbl=document.createElement('span');klbl.className='dc-quad-key';klbl.textContent=key+':';row.appendChild(klbl);
      ['0','1','2','3'].forEach(val=>{
        const btn=document.createElement('button');
        btn.className='dc-qbtn';btn.textContent=val;
        btn.title=`Set ${key}=${val} for all Q${q.num} teeth`;
        btn.addEventListener('click',()=>{
          q.teeth.forEach(id=>{
            if(!dcFindings[id])dcFindings[id]={};
            // Only apply if tooth is not missing
            if(dcFindings[id].Miss!=='Miss'){dcFindings[id][key]=val;}
          });
          dcRenderCharts();
          dcAutoSave();
        });
        row.appendChild(btn);
      });
    });
    grid.appendChild(row);
  });
  panel.appendChild(grid);
}

// ── Species setter ────────────────────────────────────────────────────────
window.dcSetSpecies=function(s){
  dcSpecies=s;dcFindings={};
  const ra=document.getElementById('dcReportArea');
  const wrapEl=document.getElementById('dcReportWrap');
  if(ra)ra.value='';if(wrapEl)wrapEl.classList.add('hidden');
  const rpa=document.getElementById('dcReportArea');
  if(rpa)rpa.classList&&rpa.classList.add('hidden');
  dcRenderCharts();buildQuadPanel();
};

// ── Auto-scrape ───────────────────────────────────────────────────────────
async function dcAutoScrape(){
  try{
    const [tab]=await chrome.tabs.query({active:true,currentWindow:true});
    if(!tab)return;
    const results=await chrome.scripting.executeScript({
      target:{tabId:tab.id,allFrames:false},
      func:()=>{
        try{
          const mana=document.getElementById('mana');
          if(!mana)return{error:'no mana iframe'};
          const doc=mana.contentDocument||mana.contentWindow.document;
          const animalEl=[...doc.querySelectorAll('div.mana-info-panels-title')].find(el=>/\(\d{4,6}\)/.test(el.innerText));
          const animalText=animalEl?animalEl.innerText.trim():'';
          const numMatch=animalText.match(/\((\d+)\)/);
          const ownerEl=doc.querySelector('#topMenuBar-lastName-info');
          const speciesEl=doc.querySelector('#patientSpecies');
          return{
            patientName:animalText.replace(/\s*\(\d+\)/,'').trim(),
            patientNumber:numMatch?numMatch[1]:'',
            ownerSurname:ownerEl?ownerEl.innerText.trim():'',
            species:speciesEl?speciesEl.innerText.trim():'',
          };
        }catch(e){return{error:e.message};}
      }
    });
    const data=results&&results[0]&&results[0].result;
    if(!data||data.error||(!data.patientName&&!data.ownerSurname))return;
    const nameEl=document.getElementById('dcPatientName');
    const subEl=document.getElementById('dcPatientSub');
    const ownerEl=document.getElementById('dc_owner');
    const numEl=document.getElementById('dc_number');
    const bar=document.getElementById('dcInfoBar');
    if(nameEl)nameEl.value=data.patientName||'';
    if(subEl)subEl.value=data.species||'';
    if(ownerEl)ownerEl.value=data.ownerSurname||'';
    if(numEl)numEl.value=data.patientNumber||'';
    if(bar)bar.classList.add('loaded');
    dcPatientNum=data.patientNumber||'';
    if(data.species){
      const s=data.species.toLowerCase();
      if(s.includes('feline')||s.includes('cat'))dcSpecies='feline';
      else if(s.includes('canine')||s.includes('dog'))dcSpecies='canine';
    }
    const loaded=await dcLoadFromStorage(dcPatientNum);
    if(!loaded){dcFindings={};dcRenderCharts();buildQuadPanel();}
  }catch(e){console.log('Dental scrape:',e.message);}
}

// ── PNG Export ────────────────────────────────────────────────────────────
window.dcExportPNG=function(){
  const btn=document.getElementById('dcExportBtn');
  btn.textContent='Rendering…';
  const name=document.getElementById('dcPatientName').value||'—';
  const owner=document.getElementById('dc_owner').value||'—';
  const num=document.getElementById('dc_number').value||'—';
  const date=document.getElementById('dc_date').value||'—';
  const vet=document.getElementById('dc_vet').value||'—';
  const d=TEETH[dcSpecies];

  const CELL_H=16,SHAPE_H=28,NUM_H=14,ROW_LBL_W=28,CENTER_W=36;
  const nLeft=Math.max(d.maxL.length,d.manL.length);
  const nRight=Math.max(d.maxR.length,d.manR.length);
  const CELL_W=Math.floor((1360-ROW_LBL_W-CENTER_W)/(nLeft+nRight));
  const JAW_W=ROW_LBL_W+nLeft*CELL_W+CENTER_W+nRight*CELL_W;
  const SCORE_ROWS=ALL_KEYS.length;
  const JAW_H=SCORE_ROWS*CELL_H+SHAPE_H+NUM_H;
  const HEADER_H=64,GAP=8,FOOT_H=28;
  const W=JAW_W+20,H=HEADER_H+JAW_H*2+GAP+FOOT_H;

  const canvas=document.createElement('canvas');canvas.width=W;canvas.height=H;
  const ctx=canvas.getContext('2d');
  ctx.fillStyle='#fff';ctx.fillRect(0,0,W,H);
  ctx.strokeStyle='#ddd';ctx.lineWidth=1;ctx.strokeRect(4,4,W-8,H-8);

  ctx.fillStyle='#111';ctx.font='bold 15px monospace';ctx.textAlign='center';
  ctx.fillText((dcSpecies==='canine'?'Canine':'Feline')+' Dental Chart',W/2,22);
  ctx.font='10px monospace';ctx.fillStyle='#444';
  ctx.fillText('Patient: '+name+'   Owner: '+owner+'   #'+num+'   Date: '+date+'   Vet: '+vet,W/2,42);
  ctx.strokeStyle='#eee';ctx.lineWidth=0.5;
  ctx.beginPath();ctx.moveTo(10,52);ctx.lineTo(W-10,52);ctx.stroke();

  const fills={g0:'#9FE1CB',g1:'#FAEEDA',g2:'#FAC775',g3:'#F09595',g4:'#E24B4A',gmiss:'#B4B2A9',gext:'#7aaed6'};

  function drawJaw(isUpper,leftTeeth,rightTeeth,startY){
    const jawLabel=isUpper?'UPPER':'LOWER';
    const allRows=isUpper?[...[...ALL_KEYS].reverse(),'shape','num']:['num','shape',...ALL_KEYS];

    allRows.forEach((row,ri)=>{
      const y=startY+ri*(row==='shape'?SHAPE_H:row==='num'?NUM_H:CELL_H);
      const rowH=row==='shape'?SHAPE_H:row==='num'?NUM_H:CELL_H;

      // Row label
      if(row!=='shape'&&row!=='num'){
        ctx.fillStyle='#fafaf8';ctx.fillRect(10,y,ROW_LBL_W,rowH);
        ctx.strokeStyle='#eee';ctx.lineWidth=0.5;ctx.strokeRect(10,y,ROW_LBL_W,rowH);
        ctx.fillStyle='#888';ctx.font='bold 7px monospace';ctx.textAlign='right';
        ctx.fillText(row,10+ROW_LBL_W-3,y+rowH/2+3);
      } else {
        ctx.fillStyle='#fafaf8';ctx.fillRect(10,y,ROW_LBL_W,rowH);
      }

      // Left teeth
      leftTeeth.forEach((id,ci)=>{
        const x=10+ROW_LBL_W+ci*CELL_W;
        const f=getF(id);
        const absent=f.Miss==='Miss';
        if(row==='num'){
          ctx.fillStyle=ci%2===0?'#fafafa':'#fff';ctx.fillRect(x,y,CELL_W,rowH);
          ctx.fillStyle='#888';ctx.font='6px monospace';ctx.textAlign='center';
          ctx.fillText(id,x+CELL_W/2,y+rowH-3);
        } else if(row==='shape'){
          ctx.fillStyle='#f8f8f8';ctx.fillRect(x,y,CELL_W,rowH);
          const t=TEETH[dcSpecies].t[id]||'I';
          const sw=Math.min(TOOTH_W[t]||12,CELL_W-4);
          const sh=TOOTH_H[t]||12;
          const sx=x+(CELL_W-sw)/2;const sy=y+(rowH-sh)/2;
          ctx.fillStyle=toothColor(id);ctx.strokeStyle='#aaa';ctx.lineWidth=0.6;
          roundRect(ctx,sx,sy,sw,sh,2);ctx.fill();ctx.stroke();
        } else {
          const isNA=row==='F'&&!FURC.has(id);
          const greyed=absent&&row!=='Miss'&&row!=='Ext';
          const val=f[row]||'';
          const gClass=gc(row,val);
          ctx.fillStyle=isNA?'#f5f5f5':greyed?'#f0ede8':fills[gClass]||'#fafafa';
          ctx.strokeStyle='#eee';ctx.lineWidth=0.3;
          ctx.fillRect(x,y,CELL_W,rowH);ctx.strokeRect(x,y,CELL_W,rowH);
          if(val&&!greyed&&!isNA){
            ctx.fillStyle='#444';ctx.font='bold 7px monospace';ctx.textAlign='center';
            ctx.fillText(val,x+CELL_W/2,y+rowH/2+3);
          }
        }
      });

      // Center
      const cx=10+ROW_LBL_W+leftTeeth.length*CELL_W;
      ctx.fillStyle='#2d5a3d';ctx.fillRect(cx,y,CENTER_W,rowH);
      if(row==='CI'){
        ctx.fillStyle='#fff';ctx.font='bold 7px monospace';ctx.textAlign='center';
        ctx.fillText(jawLabel,cx+CENTER_W/2,y+rowH/2+3);
      }

      // Right teeth
      rightTeeth.forEach((id,ci)=>{
        const x=10+ROW_LBL_W+leftTeeth.length*CELL_W+CENTER_W+ci*CELL_W;
        const f=getF(id);const absent=f.Miss==='Miss';
        if(row==='num'){
          ctx.fillStyle=ci%2===0?'#fafafa':'#fff';ctx.fillRect(x,y,CELL_W,rowH);
          ctx.fillStyle='#888';ctx.font='6px monospace';ctx.textAlign='center';
          ctx.fillText(id,x+CELL_W/2,y+rowH-3);
        } else if(row==='shape'){
          ctx.fillStyle='#f8f8f8';ctx.fillRect(x,y,CELL_W,rowH);
          const t=TEETH[dcSpecies].t[id]||'I';
          const sw=Math.min(TOOTH_W[t]||12,CELL_W-4);
          const sh=TOOTH_H[t]||12;
          const sx=x+(CELL_W-sw)/2;const sy=y+(rowH-sh)/2;
          ctx.fillStyle=toothColor(id);ctx.strokeStyle='#aaa';ctx.lineWidth=0.6;
          roundRect(ctx,sx,sy,sw,sh,2);ctx.fill();ctx.stroke();
        } else {
          const isNA=row==='F'&&!FURC.has(id);
          const greyed=absent&&row!=='Miss'&&row!=='Ext';
          const val=f[row]||'';const gClass=gc(row,val);
          ctx.fillStyle=isNA?'#f5f5f5':greyed?'#f0ede8':fills[gClass]||'#fafafa';
          ctx.strokeStyle='#eee';ctx.lineWidth=0.3;
          ctx.fillRect(x,y,CELL_W,rowH);ctx.strokeRect(x,y,CELL_W,rowH);
          if(val&&!greyed&&!isNA){
            ctx.fillStyle='#444';ctx.font='bold 7px monospace';ctx.textAlign='center';
            ctx.fillText(val,x+CELL_W/2,y+rowH/2+3);
          }
        }
      });
    });
  }

  function roundRect(c,x,y,w,h,r){
    c.beginPath();c.moveTo(x+r,y);c.lineTo(x+w-r,y);c.arcTo(x+w,y,x+w,y+r,r);
    c.lineTo(x+w,y+h-r);c.arcTo(x+w,y+h,x+w-r,y+h,r);c.lineTo(x+r,y+h);
    c.arcTo(x,y+h,x,y+h-r,r);c.lineTo(x,y+r);c.arcTo(x,y,x+r,y,r);c.closePath();
  }

  const upperRowCount=ALL_KEYS.length+2;// scores + shape + num
  const upperH=ALL_KEYS.length*CELL_H+SHAPE_H+NUM_H;
  drawJaw(true,d.maxL,d.maxR,HEADER_H);
  drawJaw(false,d.manL,d.manR,HEADER_H+upperH+GAP);

  ctx.font='8px monospace';ctx.fillStyle='#bbb';ctx.textAlign='center';
  ctx.fillText('Animana Dental Chart  •  '+owner+' / '+num+'  •  '+date,W/2,H-8);

  const url=canvas.toDataURL('image/png');
  const fname=(owner.replace(/\s+/g,'_')||'patient')+'_'+(num||'000')+'_dental_'+new Date().toISOString().slice(0,10)+'.png';

  // Convert canvas to blob
  fetch(url).then(r=>r.blob()).then(async blob=>{

    // Upload to Animana as attachment
    btn.textContent='Uploading to Animana…';
    try {
      // Scrape client.id and patient.id from the live mana iframe
      const [tab]=await chrome.tabs.query({active:true,currentWindow:true});
      const idResult=await chrome.scripting.executeScript({
        target:{tabId:tab.id,allFrames:false},
        func:()=>{
          try {
            const mana=document.getElementById('mana');
            const doc=mana?.contentDocument||mana?.contentWindow?.document;
            const form=[...doc.querySelectorAll('form')].find(f=>f.action?.includes('/web2/image/add'));
            if(form){
              const cid=form.querySelector('[name="client.id"]')?.value;
              const pid=form.querySelector('[name="patient.id"]')?.value;
              if(cid&&pid) return {clientId:cid,patientId:pid,fromForm:true};
            }
            // Fallback: scrape from patient card
            const animalEl=[...doc.querySelectorAll('div.mana-info-panels-title')]
              .find(el=>/\(\d{4,6}\)/.test(el.innerText));
            // Try to get IDs from consult button onclick
            const consultBtn=doc.getElementById('main-action-consult');
            const oc=consultBtn?.getAttribute('onclick')||'';
            const m=oc.match(/redirectToActionUrl\s*\(\s*'consult'\s*,\s*'([^']+)'\s*,\s*'([^']+)'\s*\)/);
            if(m) return {clientId:m[1],patientId:m[2],fromConsult:true};
            return {error:'IDs not found'};
          } catch(e){return {error:e.message};}
        }
      });

      const ids=idResult&&idResult[0]&&idResult[0].result;
      if(!ids||ids.error){
        showSaveStatus('Saved locally — open Animana patient file to enable direct upload','');
        return;
      }

      // Build today's date as YYYYMMDD
      const today=new Date();
      const dateStr=today.getFullYear().toString()+
        String(today.getMonth()+1).padStart(2,'0')+
        String(today.getDate()).padStart(2,'0');

      // Build multipart form
      const fd=new FormData();
      fd.append('date',dateStr);
      fd.append('category','attachment.smartflow.dental');
      fd.append('files',new File([blob],fname,{type:'image/png'}));
      fd.append('description','Dental Chart — '+fname.replace(/_/g,' ').replace('.png',''));
      fd.append('client.id',ids.clientId);
      fd.append('patient.id',ids.patientId);
      fd.append('next','/web2/patient-dossier-page');
      fd.append('dummy2','');
      fd.append('dummy3','');

      // POST to Animana (same-origin from content script via scripting.executeScript)
      const uploadResult=await chrome.scripting.executeScript({
        target:{tabId:tab.id,allFrames:false},
        func:async(clientId,patientId,dateStr,description,filenameStr,fileBase64)=>{
          try {
            // Reconstruct file from base64
            const byteStr=atob(fileBase64);
            const arr=new Uint8Array(byteStr.length);
            for(let i=0;i<byteStr.length;i++) arr[i]=byteStr.charCodeAt(i);
            const blob=new Blob([arr],{type:'image/png'});

            const fd=new FormData();
            fd.append('date',dateStr);
            fd.append('category','attachment.smartflow.dental');
            fd.append('files',new File([blob],filenameStr,{type:'image/png'}));
            fd.append('description',description);
            fd.append('client.id',clientId);
            fd.append('patient.id',patientId);
            fd.append('next','/web2/patient-dossier-page');
            fd.append('dummy2','');
            fd.append('dummy3','');

            const resp=await fetch('https://rtdvelserbroek.animana.com/web2/image/add',{
              method:'POST',body:fd,credentials:'include'
            });
            return {ok:resp.ok,status:resp.status,url:resp.url};
          } catch(e){return {error:e.message};}
        },
        args:[
          ids.clientId,
          ids.patientId,
          dateStr,
          'Dental Chart — '+fname.replace(/_/g,' ').replace('.png',''),
          fname,
          // Convert blob to base64 for passing across scripting boundary
          await new Promise(res=>{
            const reader=new FileReader();
            reader.onload=()=>res(reader.result.split(',')[1]);
            reader.readAsDataURL(blob);
          })
        ]
      });

      const result=uploadResult&&uploadResult[0]&&uploadResult[0].result;
      if(result&&result.ok){
        btn.textContent='Saved + Uploaded ✓';btn.className='dc-btn dc-btn-primary exported';
        showSaveStatus('✓ Dental chart PNG uploaded to Animana attachments','saved');

        // Reload the mana iframe so the attachment appears immediately
        await chrome.scripting.executeScript({
          target:{tabId:tab.id,allFrames:false},
          func:(clientId,patientId)=>{
            const mana=document.getElementById('mana');
            if(mana){
              mana.contentWindow.location.href=
                `/web2/patient-dossier-page?client.id=${clientId}&patient.id=${patientId}`;
            }
          },
          args:[ids.clientId,ids.patientId]
        });
      } else {
        const msg=result?.error||`HTTP ${result?.status}`;
        btn.textContent='Downloaded ✓ (upload failed)';
        showSaveStatus('PNG downloaded — Animana upload failed: '+msg,'');
      }
    } catch(e){
      btn.textContent='Downloaded ✓';
      showSaveStatus('PNG downloaded — upload error: '+e.message,'');
    }
  });

  setTimeout(()=>{btn.textContent='Export PNG';btn.className='dc-btn dc-btn-primary';},4000);
};

// ── AI Report ─────────────────────────────────────────────────────────────
window.dcGenerateReport=async function(){
  const wrapEl=document.getElementById('dcReportWrap');
  const ra=document.getElementById('dcReportArea');
  if(wrapEl)wrapEl.classList.remove('hidden');

  const d=TEETH[dcSpecies];
  const allTeeth=[...d.maxL,...d.maxR,...d.manL,...d.manR];
  const charted=Object.entries(dcFindings).filter(([,f])=>
    f.Miss==='Miss'||f.Ext==='Ext'||SCORE_KEYS.some(k=>f[k]&&f[k]!==''));
  if(!charted.length){ra.value='No findings recorded. Click score cells to begin.';return;}
  ra.value='Generating AI report…';ra.style.color='var(--accent)';

  const{apiKey}=await chrome.storage.local.get('apiKey');
  if(!apiKey){ra.value='No API key — click ⚙ Settings.';ra.style.color='';return;}

  const name=document.getElementById('dcPatientName').value||'—';
  const owner=document.getElementById('dc_owner').value||'—';
  const num=document.getElementById('dc_number').value||'—';

  const summary=charted.map(([id,f])=>{
    if(f.Miss==='Miss')return`Tooth ${id}: MISSING (absent prior to procedure)`;
    if(f.Ext==='Ext'){
      let parts=[];
      SCORE_KEYS.forEach(k=>{if(f[k]&&f[k]!==''){const desc=DESCRIPTIONS[k]&&DESCRIPTIONS[k].scores[f[k]]?DESCRIPTIONS[k].scores[f[k]]:f[k];parts.push(`${k}=${f[k]} (${desc})`)}});
      return`Tooth ${id}: EXTRACTED DURING PROCEDURE${parts.length?' — pre-extraction scores: '+parts.join('; '):''}`;
    }
    let parts=[];
    SCORE_KEYS.forEach(k=>{if(f[k]&&f[k]!==''){const desc=DESCRIPTIONS[k]&&DESCRIPTIONS[k].scores[f[k]]?DESCRIPTIONS[k].scores[f[k]]:f[k];parts.push(`${k}=${f[k]} (${desc})`)}});
    return`Tooth ${id}: ${parts.join('; ')}`;
  }).join('\n');

  const legend=Object.entries(DESCRIPTIONS).map(([k,d2])=>{
    const sc=Object.entries(d2.scores).map(([v,desc])=>`  ${v}: ${desc}`).join('\n');
    return`${d2.label}:\n${sc}`;
  }).join('\n\n');

  try{
    const resp=await fetch('https://api.anthropic.com/v1/messages',{
      method:'POST',
      headers:{'Content-Type':'application/json','x-api-key':apiKey,
        'anthropic-version':'2023-06-01','anthropic-dangerous-direct-browser-access':'true'},
      body:JSON.stringify({model:'claude-sonnet-4-20250514',max_tokens:4000,messages:[{role:'user',content:
        `You are a veterinary dental specialist writing a clinical record. Plain text only — no markdown, no bullet symbols, no ** or ## characters.\nPatient: ${name} (${dcSpecies}), Owner: ${owner}, #${num}. Triadan numbering. Missing = absent before procedure. Extracted = removed during this procedure.\n\nSCORING KEY:\n${legend}\n\nDENTAL CHART FINDINGS:\n${summary}\n\nWrite the report in this exact format:\n\nVETERINARY DENTAL CLINICAL REPORT\nPatient: ${name} (${dcSpecies})  |  Owner: ${owner}  |  #${num}  |  Date: ${new Date().toLocaleDateString('en-GB')}\n─────────────────────────────────────────────────\n\nPER-TOOTH ASSESSMENT:\n\nQuadrant 1 — Right Maxilla (100s)\n[List only teeth in this quadrant that were charted, one line each: Tooth 1XX: findings. Treatment: recommendation.]\n\nQuadrant 2 — Left Maxilla (200s)\n[List only teeth in this quadrant that were charted, one line each]\n\nQuadrant 3 — Left Mandible (300s)\n[List only teeth in this quadrant that were charted, one line each]\n\nQuadrant 4 — Right Mandible (400s)\n[List only teeth in this quadrant that were charted, one line each]\n\n─────────────────────────────────────────────────\nOVERALL SUMMARY:\n[2-3 sentence mouth-wide assessment]\n\nPRIORITY TREATMENT LIST:\n1. [treatment]\n2. [treatment]\n(continue as needed)\n\nHOMECARE: [one sentence]\nRECHECK: [interval]\n\nRules: plain text only, one line per tooth, no blank lines between individual teeth within a quadrant, omit any quadrant that has no charted teeth.`
      }]})
    });
    if(!resp.ok){const e=await resp.json().catch(()=>({}));throw new Error(e.error?.message||`API ${resp.status}`);}
    const data=await resp.json();
    const raw=data.content&&data.content[0]&&data.content[0].text||'No response.';
    const clean=raw.replace(/^#{1,6}\s+/gm,'').replace(/\*\*(.+?)\*\*/g,'$1').replace(/\*(.+?)\*/g,'$1').replace(/^---+$/gm,'─────────').trim();
    ra.value=clean;ra.style.color='';
    await dcAutoSave();
  }catch(e){ra.value='Error: '+e.message;ra.style.color='';}
};

// ── Init ──────────────────────────────────────────────────────────────────
function dcInit(){
  document.getElementById('dc_date').value=new Date().toLocaleDateString('en-GB');
  dcRenderCharts();
  buildQuadPanel();

  document.getElementById('dcReportBtn').addEventListener('click',dcGenerateReport);
  document.getElementById('dcExportBtn').addEventListener('click',dcExportPNG);
  document.getElementById('dcClearBtn').addEventListener('click',dcClearChart);

  document.getElementById('dcReportCopyBtn').addEventListener('click',()=>{
    const ra=document.getElementById('dcReportArea');
    if(!ra||!ra.value)return;
    navigator.clipboard.writeText(ra.value).then(()=>{
      const btn=document.getElementById('dcReportCopyBtn');
      btn.textContent='Copied ✓';setTimeout(()=>{btn.textContent='Copy text';},1800);
    });
  });

  let saveTimer=null;
  document.getElementById('dcReportArea').addEventListener('input',()=>{
    clearTimeout(saveTimer);showSaveStatus('Saving…','saving');
    saveTimer=setTimeout(()=>dcAutoSave(),800);
  });

  document.querySelectorAll('.tab[data-tab="dental"]').forEach(btn=>{
    btn.addEventListener('click',()=>setTimeout(dcAutoScrape,100));
  });

  // Resize popup: 960px for dental tab, 480px for all others
  document.querySelectorAll('.tab').forEach(btn=>{
    btn.addEventListener('click',()=>{
      document.body.classList.toggle('dental-open', btn.dataset.tab==='dental');
    });
  });

  // Set initial state based on which tab is active on load
  const initialTab=document.querySelector('.tab.active');
  if(initialTab){
    document.body.classList.toggle('dental-open', initialTab.dataset.tab==='dental');
  }
}

if(document.readyState==='loading'){
  document.addEventListener('DOMContentLoaded',dcInit);
}else{dcInit();}

})();
